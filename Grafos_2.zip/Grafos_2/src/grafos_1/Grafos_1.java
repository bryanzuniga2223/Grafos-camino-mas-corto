package grafos_1;

import frontend.VentanaGrafo;

/**
 * Clase principal configurada en el proyecto de NetBeans (main.class = grafos_1.Grafos_1).
 */
public class Grafos_1 {

    public static void main(String[] args) {
        VentanaGrafo.main(args);
    }
}
