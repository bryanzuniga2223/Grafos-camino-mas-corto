package pruebas;

import backend.Arista;
import backend.Grafo;
import backend.optimizacion.AlgoritmoRuta;
import backend.optimizacion.BellmanFord;
import backend.optimizacion.ComparacionAlgoritmos;
import backend.optimizacion.Dijkstra;
import backend.optimizacion.ResultadoRuta;
import frontend.ControladorRutas;
import frontend.GraphCanvasPanel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 * Pruebas de consola del módulo de caminos más cortos (Actividad 3.4).
 * Cada prueba imprime ESPERADO vs OBTENIDO y PASA/FALLA.
 * Ejecutar: clic derecho sobre este archivo en NetBeans → Run File.
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public class PruebasCaminos {

    private static int pasan;
    private static int fallan;
    private static int omitidas;

    public static void main(String[] args) throws Exception {
        System.out.println("PRUEBAS DEL MÓDULO DE CAMINOS MÁS CORTOS (Dijkstra y Bellman-Ford)");
        System.out.println("Red de ejemplo: 8 ubicaciones de Jalisco (ControladorRutas.crearRedEjemplo())");

        prueba1VecinosDirectos();
        prueba2NodosDistantes();
        prueba3DirectoDescartado();
        prueba4Inaccesibles();
        prueba5Validaciones();
        prueba6MismoCosto();
        prueba7ConsultasConsecutivas();
        prueba8PesosNegativos();
        prueba9ResaltadoEnLienzo();
        prueba10TiempoSinPausas();
        prueba11ControladorSwing();

        System.out.println();
        System.out.println("══════════════════════════════════════════════════════════════");
        System.out.println(" RESUMEN: " + pasan + " PASAN, " + fallan + " FALLAN"
                + (omitidas > 0 ? ", " + omitidas + " OMITIDAS" : "") + " (total " + (pasan + fallan) + ")");
        System.out.println("══════════════════════════════════════════════════════════════");
        System.exit(fallan == 0 ? 0 : 1);
    }

    // =====================================================================
    //  1. Vecinos directos
    // =====================================================================
    private static void prueba1VecinosDirectos() {
        titulo("1. Vecinos directos");
        Grafo g = ControladorRutas.crearRedEjemplo();
        for (AlgoritmoRuta alg : algoritmos()) {
            verificar("1 " + alg.getNombre() + " GDL→ZAP", "GDL → ZAP | costo 12", correr(alg, g, "GDL", "ZAP").r);
            verificar("1 " + alg.getNombre() + " TLQ→TON", "TLQ → TON | costo 8", correr(alg, g, "TLQ", "TON").r);
            verificar("1 " + alg.getNombre() + " GDL→ZAP tiene 1 tramo", 1, correr(alg, g, "GDL", "ZAP").r.getSaltos());
        }
    }

    // =====================================================================
    //  2. Nodos distantes
    // =====================================================================
    private static void prueba2NodosDistantes() {
        titulo("2. Nodos distantes con varios intermedios");
        Grafo g = ControladorRutas.crearRedEjemplo();
        for (AlgoritmoRuta alg : algoritmos()) {
            verificar("2 " + alg.getNombre() + " TON→CHA (3 saltos)", "TON → TLQ → TLJ → CHA | costo 56",
                    correr(alg, g, "TON", "CHA").r);
            Corrida c = correr(alg, g, "TON", "TEQ");
            verificar("2 " + alg.getNombre() + " TON→TEQ (4 saltos)", "TON → TLQ → GDL → ZAP → TEQ | costo 85", c.r);
            verificar("2 " + alg.getNombre() + " TON→TEQ costos por tramo", "[8.0, 10.0, 12.0, 55.0]",
                    c.r.getCostosTramo());
        }
    }

    // =====================================================================
    //  3. Camino directo descartado por uno indirecto más barato
    // =====================================================================
    private static void prueba3DirectoDescartado() {
        titulo("3. Camino directo (GDL→CHA = 65) descartado por uno indirecto más barato");
        Grafo g = ControladorRutas.crearRedEjemplo();
        double directa = g.buscarArista("GDL", "CHA").getPeso();
        for (AlgoritmoRuta alg : algoritmos()) {
            String n = "3 " + alg.getNombre();
            Corrida c = correr(alg, g, "GDL", "CHA");
            verificar(n + " ruta óptima", "GDL → TLQ → TLJ → CHA | costo 58", c.r);
            verificarQue(n + " costo < directa", "58 < " + fmt(directa), c.r.getCostoTotal() < directa,
                    fmt(c.r.getCostoTotal()) + " < " + fmt(directa));
            verificarContiene(n + " traza", c.traza, "ACEPTA", "DESCARTA", "mejora: antes 65 vía GDL",
                    "se DESCARTÓ", "INICIALIZACIÓN", "∞", "ITERACIONES", "RESULTADO", "ESTADÍSTICAS");
            verificar(n + " evaluaciones = aceptaciones + descartes", c.r.getEvaluaciones(),
                    c.r.getAceptaciones() + c.r.getDescartes());
        }
        verificarContiene("3 Dijkstra reporta aristas a visitados", correr(new Dijkstra(), g, "GDL", "CHA").traza,
                "ya visitado", "se extrae", "se detiene la búsqueda");
        verificarContiene("3 Bellman-Ford pasadas y verificación", correr(new BellmanFord(), g, "GDL", "CHA").traza,
                "Pasada 1 de 7", "TERMINACIÓN TEMPRANA", "VERIFICACIÓN DE CICLOS NEGATIVOS", "NO hay ciclos negativos");
    }

    // =====================================================================
    //  4. Inaccesibles
    // =====================================================================
    private static void prueba4Inaccesibles() {
        titulo("4. Nodos no conectados y ruta de un solo sentido al revés");
        Grafo g = ControladorRutas.crearRedEjemplo();
        String[][] casos = {{"GDL", "PVR"}, {"PVR", "GDL"}, {"TEQ", "ZAP"}};
        for (AlgoritmoRuta alg : algoritmos()) {
            for (String[] q : casos) {
                String n = "4 " + alg.getNombre() + " " + q[0] + "→" + q[1];
                try {
                    Corrida c = correr(alg, g, q[0], q[1]);
                    verificar(n, "INACCESIBLE | costo -", c.r);
                    verificarContiene(n + " mensaje en la traza", c.traza,
                            "DESTINO INACCESIBLE: no existe camino de " + q[0] + " a " + q[1]);
                } catch (RuntimeException ex) {
                    verificar(n, "sin excepción", "excepción: " + ex);
                }
            }
            verificar("4 " + alg.getNombre() + " ZAP→TEQ (sentido correcto)", "ZAP → TEQ | costo 55",
                    correr(alg, g, "ZAP", "TEQ").r);
        }
    }

    // =====================================================================
    //  5. Validaciones
    // =====================================================================
    private static void prueba5Validaciones() {
        titulo("5. Origen/destino vacíos, inexistentes e iguales; grafo vacío y null");
        Grafo g = ControladorRutas.crearRedEjemplo();
        verificar("5 origen vacío", "Debe escribir el ID del nodo ORIGEN.", error(() -> new Dijkstra().ejecutar(g, "", "CHA")));
        verificar("5 destino vacío (espacios)", "Debe escribir el ID del nodo DESTINO.",
                error(() -> new BellmanFord().ejecutar(g, "GDL", "   ")));
        verificar("5 origen null", "Debe escribir el ID del nodo ORIGEN.", error(() -> new Dijkstra().ejecutar(g, null, "CHA")));
        verificarQue("5 origen inexistente", "mensaje 'El nodo origen 'XYZ' no existe...'",
                error(() -> new Dijkstra().ejecutar(g, "XYZ", "CHA")).startsWith("El nodo origen 'XYZ' no existe"),
                error(() -> new Dijkstra().ejecutar(g, "XYZ", "CHA")));
        verificarQue("5 destino inexistente", "mensaje 'El nodo destino 'MTY' no existe...'",
                error(() -> new BellmanFord().ejecutar(g, "GDL", "MTY")).startsWith("El nodo destino 'MTY' no existe"),
                error(() -> new BellmanFord().ejecutar(g, "GDL", "MTY")));
        verificar("5 espacios alrededor del ID", "GDL → ZAP | costo 12", correr(new Dijkstra(), g, "  GDL ", " ZAP").r);
        for (AlgoritmoRuta alg : algoritmos()) {
            Corrida c = correr(alg, g, "GDL", "GDL");
            verificar("5 " + alg.getNombre() + " origen = destino", "GDL | costo 0", c.r);
            verificar("5 " + alg.getNombre() + " origen = destino sin evaluar aristas", 0, c.r.getEvaluaciones());
            verificarContiene("5 " + alg.getNombre() + " origen = destino explicado", c.traza,
                    "Origen = destino (GDL)", "COSTO TOTAL: 0");
        }
        verificar("5 grafo vacío", "El grafo está vacío: agregue ubicaciones y rutas antes de calcular un camino.",
                error(() -> new Dijkstra().ejecutar(new Grafo(), "A", "B")));
        verificar("5 grafo null", "El grafo no ha sido creado. Pulse 'Crear Grafo' (o 'Red de ejemplo') primero.",
                error(() -> new BellmanFord().ejecutar((Grafo) null, "A", "B")));
    }

    // =====================================================================
    //  6. Mismo costo en ambos algoritmos (+ referencia Floyd-Warshall)
    // =====================================================================
    private static void prueba6MismoCosto() {
        titulo("6. Dijkstra y Bellman-Ford dan el mismo costo");
        Grafo red = ControladorRutas.crearRedEjemplo();
        verificar("6 red de ejemplo: todos los pares (8 x 8 = 64 consultas)", "0 discrepancias",
                discrepancias(red) + " discrepancias");

        Random rnd = new Random(20261108L);
        int consultas = 0;
        int errores = 0;
        for (int k = 0; k < 50; k++) {
            Grafo g = grafoAleatorio(rnd, k);
            consultas += g.cantidadVertices() * g.cantidadVertices();
            errores += discrepancias(g);
        }
        verificar("6 50 grafos aleatorios (" + consultas + " consultas, contra Floyd-Warshall)", "0 discrepancias",
                errores + " discrepancias");
    }

    /** Compara Dijkstra, Bellman-Ford y Floyd-Warshall en todos los pares; valida también la ruta. */
    private static int discrepancias(Grafo g) {
        List<String> ids = g.idsEnOrden();
        double[][] fw = floydWarshall(g);
        int errores = 0;
        Dijkstra d = new Dijkstra();
        BellmanFord b = new BellmanFord();
        for (int i = 0; i < ids.size(); i++) {
            for (int j = 0; j < ids.size(); j++) {
                ResultadoRuta rd = d.ejecutar(g, ids.get(i), ids.get(j));
                ResultadoRuta rb = b.ejecutar(g, ids.get(i), ids.get(j));
                boolean ok = ComparacionAlgoritmos.mismoCosto(rd, rb)
                        && rd.isAlcanzable() == !Double.isInfinite(fw[i][j])
                        && (!rd.isAlcanzable() || Math.abs(rd.getCostoTotal() - fw[i][j]) < 1e-9)
                        && rutaValida(g, rd) && rutaValida(g, rb);
                if (!ok) {
                    errores++;
                    System.out.println("        discrepancia " + ids.get(i) + "→" + ids.get(j) + ": D=" + rd
                            + " BF=" + rb + " FW=" + fw[i][j]);
                }
            }
        }
        return errores;
    }

    /** La ruta empieza/termina bien, cada tramo existe y la suma de pesos es el costo. */
    private static boolean rutaValida(Grafo g, ResultadoRuta r) {
        if (!r.isAlcanzable()) return r.getRuta().isEmpty();
        List<String> ruta = r.getRuta();
        if (!ruta.get(0).equals(r.getOrigen()) || !ruta.get(ruta.size() - 1).equals(r.getDestino())) return false;
        double suma = 0;
        for (int i = 0; i + 1 < ruta.size(); i++) {
            Arista a = g.buscarArista(ruta.get(i), ruta.get(i + 1));
            if (a == null) return false;
            suma += a.getPeso();
        }
        return Math.abs(suma - r.getCostoTotal()) < 1e-9;
    }

    private static double[][] floydWarshall(Grafo g) {
        List<String> ids = g.idsEnOrden();
        int n = ids.size();
        double[][] m = new double[n][n];
        for (int i = 0; i < n; i++) {
            Arrays.fill(m[i], Double.POSITIVE_INFINITY);
            m[i][i] = 0;
        }
        for (Arista a : g.getAristas()) {
            int i = ids.indexOf(a.getOrigen());
            int j = ids.indexOf(a.getDestino());
            m[i][j] = Math.min(m[i][j], a.getPeso());
        }
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (m[i][k] + m[k][j] < m[i][j]) m[i][j] = m[i][k] + m[k][j];
                }
            }
        }
        return m;
    }

    private static Grafo grafoAleatorio(Random rnd, int k) {
        Grafo g = new Grafo();
        int n = 2 + rnd.nextInt(11);               // 2 a 12 nodos
        double densidad = 0.1 + rnd.nextDouble() * 0.5;
        for (int i = 0; i < n; i++) {
            g.agregarVertice("N" + i, "Nodo " + i, "Prueba", "Activo", 1);
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j && rnd.nextDouble() < densidad) {
                    double peso = (k % 2 == 0) ? 1 + rnd.nextInt(50) : 0.1 + rnd.nextDouble() * 20;
                    g.agregarArista("N" + i, "N" + j, peso);
                }
            }
        }
        return g;
    }

    // =====================================================================
    //  7. Consultas consecutivas y después de modificar el grafo
    // =====================================================================
    private static void prueba7ConsultasConsecutivas() {
        titulo("7. Consultas consecutivas y después de eliminar un vértice");
        Grafo g = ControladorRutas.crearRedEjemplo();
        for (AlgoritmoRuta alg : algoritmos()) {
            String n = "7 " + alg.getNombre();
            ResultadoRuta r1 = correr(alg, g, "GDL", "CHA").r;
            ResultadoRuta r2 = correr(alg, g, "TON", "TEQ").r;
            ResultadoRuta r3 = correr(alg, g, "GDL", "CHA").r;
            verificar(n + " 2a consulta con la misma instancia", "TON → TLQ → GDL → ZAP → TEQ | costo 85", r2);
            verificar(n + " 3a consulta = 1a (estado reiniciado)", r1 + " | eval " + r1.getEvaluaciones(),
                    r3 + " | eval " + r3.getEvaluaciones());
        }
        g.eliminarVertice("TLQ");
        for (AlgoritmoRuta alg : algoritmos()) {
            verificar("7 " + alg.getNombre() + " sin TLQ: GDL→CHA usa la directa", "GDL → CHA | costo 65",
                    correr(alg, g, "GDL", "CHA").r);
            verificar("7 " + alg.getNombre() + " sin TLQ: TON queda aislado", "INACCESIBLE | costo -",
                    correr(alg, g, "TON", "CHA").r);
        }
        g.eliminarArista("GDL", "CHA");
        g.agregarArista("CHA", "PVR", 300);
        for (AlgoritmoRuta alg : algoritmos()) {
            verificar("7 " + alg.getNombre() + " sin GDL→CHA y con CHA→PVR", "GDL → ZAP → TLJ → CHA → PVR | costo 370",
                    correr(alg, g, "GDL", "PVR").r);
        }
        verificar("7 consultar un vértice eliminado", "El nodo origen 'TLQ' no existe",
                error(() -> new Dijkstra().ejecutar(g, "TLQ", "CHA")).replaceAll(" en el grafo.*", ""));
    }

    // =====================================================================
    //  8. Pesos negativos
    // =====================================================================
    private static void prueba8PesosNegativos() {
        titulo("8. Validación de pesos negativos de Dijkstra");
        List<Arista> negativas = new ArrayList<>();
        negativas.add(new Arista("A", "B", 4));
        negativas.add(new Arista("A", "C", 2));
        negativas.add(new Arista("C", "B", -1));
        verificar("8 validarPesosNoNegativos con peso -1",
                "Dijkstra no admite pesos negativos: la ruta C → B tiene peso -1. Use Bellman-Ford para este grafo.",
                error(() -> Dijkstra.validarPesosNoNegativos(negativas)));
        verificar("8 validarPesosNoNegativos con pesos positivos", "sin excepción",
                error(() -> Dijkstra.validarPesosNoNegativos(ControladorRutas.crearRedEjemplo().getAristas())));
        verificar("8 red de ejemplo: hayPesosNegativos()", false, ControladorRutas.crearRedEjemplo().hayPesosNegativos());
        List<String> abc = Arrays.asList("A", "B", "C");
        verificarQue("8 Dijkstra.ejecutar rechaza el grafo con peso negativo", "IllegalArgumentException",
                !error(() -> new Dijkstra().ejecutar(abc, negativas, "A", "B")).equals("sin excepción"),
                error(() -> new Dijkstra().ejecutar(abc, negativas, "A", "B")));
        verificar("8 Bellman-Ford sí acepta pesos negativos sin ciclo", "A → C → B | costo 1",
                new BellmanFord().ejecutar(abc, negativas, "A", "B"));

        List<Arista> ciclo = new ArrayList<>();
        ciclo.add(new Arista("A", "B", 1));
        ciclo.add(new Arista("B", "C", -3));
        ciclo.add(new Arista("C", "B", 1));
        StringBuilder traza = new StringBuilder();
        ResultadoRuta r = new BellmanFord(l -> traza.append(l).append('\n'), 0).ejecutar(abc, ciclo, "A", "C");
        verificar("8 Bellman-Ford detecta ciclo negativo B→C→B", true, r.isCicloNegativo());
        verificarContiene("8 traza del ciclo negativo", traza.toString(), "CICLO NEGATIVO DETECTADO", "SIN RUTA ÓPTIMA");
    }

    // =====================================================================
    //  9. Resaltado en el lienzo
    // =====================================================================
    private static void prueba9ResaltadoEnLienzo() {
        titulo("9. Resaltado del camino en GraphCanvasPanel");
        GraphCanvasPanel p = new GraphCanvasPanel();
        p.setSize(400, 200);
        cargarLienzo(p);
        p.resaltarCamino(Arrays.asList("A", "B", "C"));
        verificar("9 pixel sobre A→B resaltado", true, esColorCamino(p, 90, 100));

        // Simula redibujar(): destruirGrafoV() + volver a agregar todo
        p.destruirGrafoV();
        cargarLienzo(p);
        verificar("9 el resaltado sobrevive a redibujar()", "[A, B, C]", p.getCaminoResaltado());
        verificar("9 pixel sobre A→B sigue resaltado", true, esColorCamino(p, 90, 100));

        p.eliminarAristaV("A", "B");
        verificar("9 arista eliminada ya no se dibuja resaltada", false, esColorCamino(p, 90, 100));
        verificar("9 B→C sigue resaltada", true, esColorCamino(p, 240, 100));

        p.limpiarResaltado();
        verificar("9 limpiarResaltado()", "[]", p.getCaminoResaltado());
        verificar("9 pixel sobre B→C ya no resaltado", false, esColorCamino(p, 240, 100));
    }

    private static void cargarLienzo(GraphCanvasPanel p) {
        p.agregarNodoV("A", 50, 100);
        p.agregarNodoV("B", 200, 100);
        p.agregarNodoV("C", 350, 100);
        p.agregarAristaV("A", "B", 5);
        p.agregarAristaV("B", "C", 7);
    }

    private static boolean esColorCamino(GraphCanvasPanel p, int x, int y) {
        BufferedImage img = new BufferedImage(p.getWidth(), p.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        p.paint(g);
        g.dispose();
        return new Color(img.getRGB(x, y)).equals(GraphCanvasPanel.COLOR_CAMINO);
    }

    // =====================================================================
    //  10. El tiempo no cuenta las pausas
    // =====================================================================
    private static void prueba10TiempoSinPausas() {
        titulo("10. El tiempo medido no incluye las pausas de animación");
        Grafo g = ControladorRutas.crearRedEjemplo();
        correr(new Dijkstra(), g, "GDL", "CHA"); // calentamiento de la JVM
        long t0 = System.nanoTime();
        ResultadoRuta r = new Dijkstra(l -> { }, 20).ejecutar(g, "GDL", "CHA");
        double totalMs = (System.nanoTime() - t0) / 1e6;
        verificarQue("10 tiempo reportado << tiempo real con pausas de 20 ms",
                "tiempo < 20 ms y real >= 250 ms", r.getTiempoMs() < 20 && totalMs >= 250,
                String.format("reportado %.3f ms, real %.1f ms", r.getTiempoMs(), totalMs));
    }

    // =====================================================================
    //  11. Controlador con SwingWorker (requiere pantalla)
    // =====================================================================
    private static void prueba11ControladorSwing() throws Exception {
        titulo("11. ControladorRutas: SwingWorker, traza, resultado, resaltado y botones");
        if (GraphicsEnvironment.isHeadless()) {
            omitidas++;
            System.out.println("[OMITIDA] entorno sin pantalla (headless)");
            return;
        }
        final Grafo g = ControladorRutas.crearRedEjemplo();
        final JTextArea traza = new JTextArea();
        final JTextArea resultado = new JTextArea();
        final GraphCanvasPanel lienzo = new GraphCanvasPanel();
        final JButton boton = new JButton("Calcular");
        final AtomicReference<ControladorRutas> ref = new AtomicReference<>();
        final AtomicReference<Boolean> deshabilitado = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            ControladorRutas c = new ControladorRutas(new JFrame(), traza, resultado, lienzo, () -> g);
            c.setBotonesEjecucion(boton);
            ref.set(c);
            c.calcularRutaOptima("GDL", "CHA", ControladorRutas.DIJKSTRA, 5);
            deshabilitado.set(!boton.isEnabled());
        });
        esperar(ref.get());
        verificar("11 botón deshabilitado durante la ejecución", true, deshabilitado.get());
        verificar("11 botón habilitado al terminar", true, boton.isEnabled());
        verificarContiene("11 traza en txtTraza", traza.getText(), "DIJKSTRA", "ACEPTA", "DESCARTA", "COSTO TOTAL: 58");
        verificarContiene("11 resultado en txtResultado", resultado.getText(), "GDL → TLQ → TLJ → CHA", "Costo total: 58");
        verificar("11 camino resaltado", "[GDL, TLQ, TLJ, CHA]", lienzo.getCaminoResaltado());

        SwingUtilities.invokeAndWait(() -> ref.get().compararAlgoritmos("TON", "TEQ", 0));
        esperar(ref.get());
        verificarContiene("11 comparación", traza.getText(), "COMPARACIÓN: DIJKSTRA vs BELLMAN-FORD",
                "ambos algoritmos llegaron al MISMO costo óptimo (85)");

        SwingUtilities.invokeAndWait(() -> ref.get().calcularRutaOptima("GDL", "PVR", ControladorRutas.BELLMAN_FORD, 0));
        esperar(ref.get());
        verificarContiene("11 inaccesible dentro de la traza", traza.getText(),
                "DESTINO INACCESIBLE: no existe camino de GDL a PVR");
        verificar("11 sin resaltado si es inaccesible", "[]", lienzo.getCaminoResaltado());

        SwingUtilities.invokeAndWait(() -> ref.get().limpiarRegistro());
        verificar("11 limpiarRegistro()", "''", "'" + traza.getText() + resultado.getText() + "'");
    }

    private static void esperar(ControladorRutas c) throws Exception {
        long limite = System.currentTimeMillis() + 15000;
        final boolean[] corriendo = {true};
        while (corriendo[0] && System.currentTimeMillis() < limite) {
            Thread.sleep(50);
            SwingUtilities.invokeAndWait(() -> corriendo[0] = c.estaEjecutando());
        }
        // deja que se procesen los últimos publish()/done() pendientes
        Thread.sleep(200);
        SwingUtilities.invokeAndWait(() -> { });
    }

    // =====================================================================
    //  Utilidades
    // =====================================================================

    private static final class Corrida {
        final ResultadoRuta r;
        final String traza;

        Corrida(ResultadoRuta r, String traza) {
            this.r = r;
            this.traza = traza;
        }
    }

    private static AlgoritmoRuta[] algoritmos() {
        return new AlgoritmoRuta[]{new Dijkstra(), new BellmanFord()};
    }

    private static Corrida correr(AlgoritmoRuta alg, Grafo g, String o, String d) {
        StringBuilder sb = new StringBuilder();
        alg.setReceptor(l -> sb.append(l).append('\n'));
        alg.setPausaMs(0);
        ResultadoRuta r = alg.ejecutar(g, o, d);
        alg.setReceptor(null);
        return new Corrida(r, sb.toString());
    }

    private static String error(Runnable r) {
        try {
            r.run();
            return "sin excepción";
        } catch (IllegalArgumentException ex) {
            return ex.getMessage();
        }
    }

    private static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
    }

    private static void titulo(String t) {
        System.out.println();
        System.out.println("── " + t + " " + "─".repeat(Math.max(3, 62 - t.length())));
    }

    private static void verificar(String nombre, Object esperado, Object obtenido) {
        String e = String.valueOf(esperado);
        String o = String.valueOf(obtenido);
        reportar(nombre, e, o, e.equals(o));
    }

    private static void verificarQue(String nombre, String esperado, boolean condicion, String obtenido) {
        reportar(nombre, esperado, obtenido, condicion);
    }

    private static void verificarContiene(String nombre, String texto, String... fragmentos) {
        List<String> faltan = new ArrayList<>();
        for (String f : fragmentos) {
            if (!texto.contains(f)) faltan.add(f);
        }
        reportar(nombre, "contiene " + Arrays.toString(fragmentos),
                faltan.isEmpty() ? "contiene todos" : "faltan " + faltan, faltan.isEmpty());
    }

    private static void reportar(String nombre, String esperado, String obtenido, boolean ok) {
        if (ok) pasan++;
        else fallan++;
        System.out.println((ok ? "[PASA]  " : "[FALLA] ") + nombre);
        System.out.println("        ESPERADO: " + esperado);
        System.out.println("        OBTENIDO: " + obtenido);
    }
}
