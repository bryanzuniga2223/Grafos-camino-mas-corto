/*
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
package frontend;

import backend.Arista;
import backend.Grafo;
import backend.Vertice;
import backend.optimizacion.AlgoritmoRuta;
import backend.optimizacion.BellmanFord;
import backend.optimizacion.ComparacionAlgoritmos;
import backend.optimizacion.Dijkstra;
import backend.optimizacion.Formato;
import backend.optimizacion.ResultadoRuta;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

/**
 * Controlador del módulo de caminos más cortos (Actividad 3.4).
 *
 * Concentra toda la lógica de la interfaz de rutas para que los eventos de los botones
 * de VentanaGrafo sean de 1 a 3 líneas. Los algoritmos se ejecutan en un SwingWorker:
 * cada línea de la traza se envía con publish() y aparece en tiempo real en txtTraza,
 * sin congelar la ventana.
 *
 * Recibe el grafo mediante un Supplier porque el campo "grafo" de VentanaGrafo puede ser
 * null o reemplazarse al pulsar "Crear Grafo"; así siempre se usa el grafo actual.
 */
public class ControladorRutas {

    /** Índices del JComboBox cmbAlgoritmo. */
    public static final int DIJKSTRA = 0;
    public static final int BELLMAN_FORD = 1;

    private final JFrame ventana;
    private final JTextArea txtTraza;
    private final JTextArea txtResultado;
    private final GraphCanvasPanel lienzo;
    private final Supplier<Grafo> proveedorGrafo;

    private JButton[] botonesEjecucion = new JButton[0];
    private boolean[] estadoPrevioBotones = new boolean[0];
    private SwingWorker<List<ResultadoRuta>, String> trabajo;

    public ControladorRutas(JFrame ventana, JTextArea txtTraza, JTextArea txtResultado,
            GraphCanvasPanel lienzo, Supplier<Grafo> proveedorGrafo) {
        if (txtTraza == null || txtResultado == null || proveedorGrafo == null) {
            throw new IllegalArgumentException("txtTraza, txtResultado y proveedorGrafo son obligatorios.");
        }
        this.ventana = ventana;
        this.txtTraza = txtTraza;
        this.txtResultado = txtResultado;
        this.lienzo = lienzo;
        this.proveedorGrafo = proveedorGrafo;
        Font mono = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        txtTraza.setFont(mono);
        txtResultado.setFont(mono);
        txtTraza.setEditable(false);
        txtResultado.setEditable(false);
    }

    /** Botones que se deshabilitan mientras corre un algoritmo. */
    public void setBotonesEjecucion(JButton... botones) {
        this.botonesEjecucion = botones == null ? new JButton[0] : botones.clone();
    }

    public boolean estaEjecutando() {
        return trabajo != null && !trabajo.isDone();
    }

    // =====================================================================
    //  Acciones de los botones
    // =====================================================================

    /** Botón "Calcular ruta": valida, ejecuta el algoritmo elegido y muestra la traza en vivo. */
    public void calcularRutaOptima(String origen, String destino, int indiceAlgoritmo, int pausaMs) {
        Consulta c = prepararConsulta(origen, destino);
        if (c == null) return;
        if (indiceAlgoritmo != DIJKSTRA && indiceAlgoritmo != BELLMAN_FORD) {
            avisar("Seleccione un algoritmo en la lista (Dijkstra o Bellman-Ford).");
            return;
        }
        if (indiceAlgoritmo == DIJKSTRA && !validarDijkstra(c)) return;
        List<AlgoritmoRuta> algoritmos = new ArrayList<>();
        algoritmos.add(crearAlgoritmo(indiceAlgoritmo));
        lanzar(algoritmos, c, pausaMs, false);
    }

    /** Botón "Comparar": ejecuta ambos algoritmos sobre el mismo grafo y agrega la tabla comparativa. */
    public void compararAlgoritmos(String origen, String destino, int pausaMs) {
        Consulta c = prepararConsulta(origen, destino);
        if (c == null) return;
        if (!validarDijkstra(c)) return;
        List<AlgoritmoRuta> algoritmos = new ArrayList<>();
        algoritmos.add(crearAlgoritmo(DIJKSTRA));
        algoritmos.add(crearAlgoritmo(BELLMAN_FORD));
        lanzar(algoritmos, c, pausaMs, true);
    }

    /** Botón "Limpiar": vacía la traza y el resultado y quita el resaltado del dibujo. */
    public void limpiarRegistro() {
        txtTraza.setText("");
        txtResultado.setText("");
        if (lienzo != null) lienzo.limpiarResaltado();
    }

    /**
     * Botón "Red de ejemplo": crea la red de Jalisco y la entrega a la ventana.
     * Uso en VentanaGrafo: controlador.cargarRedEjemplo(g -> grafo = g, this::redibujar);
     *
     * @return true si se cargó
     */
    public boolean cargarRedEjemplo(Consumer<Grafo> asignarGrafo, Runnable redibujar) {
        if (estaEjecutando()) {
            avisar("Espere a que termine el cálculo actual.");
            return false;
        }
        Grafo actual = proveedorGrafo.get();
        if (actual != null && !actual.estaVacio()) {
            int r = JOptionPane.showConfirmDialog(ventana,
                    "Ya existe un grafo con datos. ¿Desea reemplazarlo por la red de ejemplo de Jalisco?",
                    "Red de ejemplo", JOptionPane.YES_NO_OPTION);
            if (r != JOptionPane.YES_OPTION) return false;
        }
        Grafo g = crearRedEjemplo();
        asignarGrafo.accept(g);
        limpiarRegistro();
        if (redibujar != null) redibujar.run();
        txtTraza.setText(describirRed(g));
        txtTraza.setCaretPosition(0);
        txtResultado.setText("Red de ejemplo cargada: " + g.cantidadVertices() + " ubicaciones, "
                + g.cantidadAristas() + " rutas.\nEscriba origen y destino (p. ej. GDL y CHA) y pulse Calcular.");
        return true;
    }

    // =====================================================================
    //  Red de ejemplo
    // =====================================================================

    /**
     * Red de 8 ubicaciones de Jalisco (pesos = km aproximados, valores didácticos).
     * El grafo es dirigido: una carretera de doble sentido se crea como DOS aristas.
     * <ul>
     * <li>Ruta directa cara: GDL→CHA (65, un solo sentido) vs GDL→TLQ→TLJ→CHA (58).</li>
     * <li>Vecinos directos: GDL↔ZAP (12), GDL↔TLQ (10), TLQ↔TON (8).</li>
     * <li>3 o más saltos: TON→CHA (56, 3 saltos), TON→TEQ (85, 4 saltos).</li>
     * <li>Un solo sentido: ZAP→TEQ (no hay regreso) y GDL→CHA.</li>
     * <li>Sin conexión: PVR (Puerto Vallarta) → inaccesible desde cualquier nodo.</li>
     * </ul>
     */
    public static Grafo crearRedEjemplo() {
        Grafo g = new Grafo();
        // capacidad = población aproximada en miles de habitantes
        g.agregarVertice("GDL", "Guadalajara", "Ciudad", "Activo", 1385);
        g.agregarVertice("ZAP", "Zapopan", "Ciudad", "Activo", 1476);
        g.agregarVertice("TLQ", "San Pedro Tlaquepaque", "Ciudad", "Activo", 687);
        g.agregarVertice("TON", "Tonalá", "Ciudad", "Activo", 569);
        g.agregarVertice("TLJ", "Tlajomulco de Zúñiga", "Municipio", "Activo", 727);
        g.agregarVertice("CHA", "Chapala", "Municipio", "Activo", 50);
        g.agregarVertice("TEQ", "Tequila", "Pueblo Mágico", "Activo", 45);
        g.agregarVertice("PVR", "Puerto Vallarta", "Ciudad costera", "Sin conexión", 291);

        dobleSentido(g, "GDL", "ZAP", 12);
        dobleSentido(g, "GDL", "TLQ", 10);
        g.agregarArista("GDL", "CHA", 65);      // directa, un solo sentido y más cara
        dobleSentido(g, "TLQ", "TON", 8);
        dobleSentido(g, "TLQ", "TLJ", 18);
        dobleSentido(g, "ZAP", "TLJ", 28);
        dobleSentido(g, "TLJ", "CHA", 30);
        g.agregarArista("ZAP", "TEQ", 55);      // un solo sentido: de Tequila no se regresa
        // PVR no tiene rutas: queda inaccesible
        return g;
    }

    private static void dobleSentido(Grafo g, String a, String b, double km) {
        g.agregarArista(a, b, km);
        g.agregarArista(b, a, km);
    }

    private static String describirRed(Grafo g) {
        StringBuilder sb = new StringBuilder();
        sb.append("RED DE EJEMPLO: JALISCO (grafo dirigido, pesos en km)\n");
        sb.append(Formato.repetir('─', 55)).append('\n');
        for (Vertice v : g.getVertices()) {
            List<Arista> salientes = g.aristasSalientes(v.getId());
            sb.append(Formato.der(v.getId(), 4)).append(Formato.der(v.getNombre(), 22)).append("→ ");
            if (salientes.isEmpty()) {
                sb.append("(sin rutas de salida)");
            }
            for (int i = 0; i < salientes.size(); i++) {
                Arista a = salientes.get(i);
                if (i > 0) sb.append(", ");
                sb.append(a.getDestino()).append('(').append(Formato.num(a.getPeso())).append(')');
            }
            sb.append('\n');
        }
        sb.append('\n');
        sb.append("Consultas sugeridas:\n");
        sb.append("  GDL → ZAP  vecinos directos (12)\n");
        sb.append("  GDL → CHA  la directa (65) se descarta: GDL→TLQ→TLJ→CHA cuesta 58\n");
        sb.append("  TON → TEQ  4 saltos (85)\n");
        sb.append("  TEQ → ZAP  ruta de un solo sentido al revés: inaccesible\n");
        sb.append("  GDL → PVR  nodo sin conexión: inaccesible\n");
        return sb.toString();
    }

    public static AlgoritmoRuta crearAlgoritmo(int indice) {
        return indice == BELLMAN_FORD ? new BellmanFord() : new Dijkstra();
    }

    // =====================================================================
    //  Validación y ejecución en segundo plano
    // =====================================================================

    /** "Foto" del grafo tomada en el hilo de la interfaz antes de empezar. */
    private static final class Consulta {
        final List<String> nodos;
        final List<Arista> aristas;
        final String origen;
        final String destino;

        Consulta(List<String> nodos, List<Arista> aristas, String origen, String destino) {
            this.nodos = nodos;
            this.aristas = aristas;
            this.origen = origen;
            this.destino = destino;
        }
    }

    private Consulta prepararConsulta(String origen, String destino) {
        if (estaEjecutando()) {
            avisar("Espere a que termine el cálculo actual.");
            return null;
        }
        Grafo g = proveedorGrafo.get();
        try {
            AlgoritmoRuta.validarConsulta(g, origen, destino);
        } catch (IllegalArgumentException ex) {
            avisar(ex.getMessage());
            return null;
        }
        // Copias: si el usuario modifica el grafo mientras corre el algoritmo, no hay conflicto.
        return new Consulta(g.idsEnOrden(), g.getAristas(), origen.trim(), destino.trim());
    }

    private boolean validarDijkstra(Consulta c) {
        try {
            Dijkstra.validarPesosNoNegativos(c.aristas);
            return true;
        } catch (IllegalArgumentException ex) {
            avisar(ex.getMessage());
            return false;
        }
    }

    private void lanzar(final List<AlgoritmoRuta> algoritmos, final Consulta c, int pausaMs, final boolean comparar) {
        limpiarRegistro();
        final long pausa = Math.max(0, Math.min(pausaMs, 5000));
        habilitarBotones(false);
        txtResultado.setText("Calculando...");

        trabajo = new SwingWorker<List<ResultadoRuta>, String>() {
            @Override
            protected List<ResultadoRuta> doInBackground() {
                List<ResultadoRuta> resultados = new ArrayList<>();
                for (int i = 0; i < algoritmos.size(); i++) {
                    AlgoritmoRuta alg = algoritmos.get(i);
                    alg.setReceptor(linea -> publish(linea));
                    alg.setPausaMs(pausa);
                    if (i > 0) {
                        publish("");
                        publish("");
                    }
                    resultados.add(alg.ejecutar(c.nodos, c.aristas, c.origen, c.destino));
                }
                if (comparar && resultados.size() == 2) {
                    publish("");
                    publish("");
                    for (String l : ComparacionAlgoritmos.tabla(resultados.get(0), resultados.get(1))) {
                        publish(l);
                    }
                }
                return resultados;
            }

            @Override
            protected void process(List<String> lineas) {
                StringBuilder sb = new StringBuilder();
                for (String l : lineas) sb.append(l).append('\n');
                txtTraza.append(sb.toString());
                txtTraza.setCaretPosition(txtTraza.getDocument().getLength());
            }

            @Override
            protected void done() {
                try {
                    mostrarResultados(get(), comparar);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (CancellationException ex) {
                    txtResultado.setText("Cálculo cancelado.");
                } catch (ExecutionException ex) {
                    Throwable causa = ex.getCause() != null ? ex.getCause() : ex;
                    txtTraza.append("\n[ERROR] " + causa.getMessage() + "\n");
                    avisar(causa.getMessage());
                } finally {
                    habilitarBotones(true);
                }
            }
        };
        trabajo.execute();
    }

    private void mostrarResultados(List<ResultadoRuta> resultados, boolean comparar) {
        if (resultados.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (ResultadoRuta r : resultados) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(r.resumen());
        }
        if (comparar && resultados.size() == 2) {
            sb.append('\n').append(ComparacionAlgoritmos.conclusion(resultados.get(0), resultados.get(1)));
        }
        txtResultado.setText(sb.toString());
        txtResultado.setCaretPosition(0);

        if (lienzo == null) return;
        ResultadoRuta primero = resultados.get(0);
        if (primero.isAlcanzable()) {
            lienzo.resaltarCamino(primero.getRuta());
        } else {
            lienzo.limpiarResaltado();
        }
    }

    private void habilitarBotones(boolean habilitar) {
        if (!habilitar) {
            estadoPrevioBotones = new boolean[botonesEjecucion.length];
            for (int i = 0; i < botonesEjecucion.length; i++) {
                if (botonesEjecucion[i] == null) continue;
                estadoPrevioBotones[i] = botonesEjecucion[i].isEnabled();
                botonesEjecucion[i].setEnabled(false);
            }
        } else {
            for (int i = 0; i < botonesEjecucion.length; i++) {
                if (botonesEjecucion[i] == null) continue;
                botonesEjecucion[i].setEnabled(i < estadoPrevioBotones.length ? estadoPrevioBotones[i] : true);
            }
        }
    }

    /** Mensaje de validación: en el área de resultado y en un cuadro de diálogo. */
    private void avisar(String mensaje) {
        txtResultado.setText("[VALIDACIÓN] " + mensaje);
        JOptionPane.showMessageDialog(ventana, mensaje, "Validación", JOptionPane.WARNING_MESSAGE);
    }
}
