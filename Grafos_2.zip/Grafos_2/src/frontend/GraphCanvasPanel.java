/*
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
package frontend;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.RenderingHints;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.awt.BasicStroke;
import java.awt.Stroke;
import java.util.Collections;

public class GraphCanvasPanel extends JPanel {
    
    
    class NodoGrafico {
        String id; int x, y;
        public NodoGrafico(String id, int x, int y) { this.id = id; this.x = x; this.y = y; }
    }
    class AristaGrafica {
        String origen, destino; double peso;
        public AristaGrafica(String origen, String destino, double peso) {
            this.origen = origen; this.destino = destino; this.peso = peso;
        }
    }

    private Map<String, NodoGrafico> nodos = new HashMap<>();
    private List<AristaGrafica> aristas = new ArrayList<>();

    /** Color del camino resaltado (Actividad 3.4). */
    public static final Color COLOR_CAMINO = new Color(255, 120, 0);
    /**
     * IDs del camino resaltado, en orden. No se borra en destruirGrafoV(), así que
     * sobrevive a redibujar() (que vuelve a agregar nodos y aristas al cambiar el tamaño).
     */
    private final List<String> caminoResaltado = new ArrayList<>();

    public GraphCanvasPanel() {
        setBackground(Color.WHITE); 
    }

    public void agregarNodoV(String id, int x, int y) {
        nodos.put(id, new NodoGrafico(id, x, y));
        repaint(); 
    }

    public void agregarAristaV(String origen, String destino, double peso) {
        aristas.add(new AristaGrafica(origen, destino, peso));
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Suavizar bordes

        
        g2.setColor(Color.BLACK);
        for (AristaGrafica a : aristas) {
            NodoGrafico n1 = nodos.get(a.origen);
            NodoGrafico n2 = nodos.get(a.destino);
            if (n1 != null && n2 != null) {
                g2.drawLine(n1.x, n1.y, n2.x, n2.y);
                
                g2.setColor(Color.RED);
                g2.drawString(String.valueOf(a.peso), (n1.x + n2.x)/2, (n1.y + n2.y)/2);
                g2.setColor(Color.BLACK);
            }
        }

        
        int radio = 15;
        dibujarAristasResaltadas(g2, radio);
        Stroke trazoOriginal = g2.getStroke();
        for (NodoGrafico n : nodos.values()) {
            boolean enCamino = caminoResaltado.contains(n.id);
            g2.setColor(enCamino ? COLOR_CAMINO : Color.CYAN);
            g2.fillOval(n.x - radio, n.y - radio, radio * 2, radio * 2);
            g2.setColor(Color.BLACK);
            if (enCamino) g2.setStroke(new BasicStroke(3f));
            g2.drawOval(n.x - radio, n.y - radio, radio * 2, radio * 2);
            g2.setStroke(trazoOriginal);
            g2.drawString(n.id, n.x - 5, n.y + 5); // Texto del ID
        }
    }

    // ------------------------------------------------ resaltado del camino (3.4)

    /** Resalta el camino (lista de IDs en orden). null o vacío = quitar el resaltado. */
    public void resaltarCamino(List<String> ids) {
        caminoResaltado.clear();
        if (ids != null) caminoResaltado.addAll(ids);
        repaint();
    }

    public void limpiarResaltado() {
        caminoResaltado.clear();
        repaint();
    }

    public List<String> getCaminoResaltado() {
        return Collections.unmodifiableList(new ArrayList<>(caminoResaltado));
    }

    /**
     * Dibuja en otro color y más gruesas las aristas u→v del camino, solo si la arista y
     * sus dos nodos siguen existiendo en el panel. Agrega una flecha para indicar el sentido.
     */
    private void dibujarAristasResaltadas(Graphics2D g2, int radio) {
        if (caminoResaltado.size() < 2) return;
        Stroke trazoOriginal = g2.getStroke();
        for (int i = 0; i + 1 < caminoResaltado.size(); i++) {
            String u = caminoResaltado.get(i);
            String v = caminoResaltado.get(i + 1);
            NodoGrafico n1 = nodos.get(u);
            NodoGrafico n2 = nodos.get(v);
            AristaGrafica arista = null;
            for (AristaGrafica a : aristas) {
                if (a.origen.equals(u) && a.destino.equals(v)) { arista = a; break; }
            }
            if (n1 == null || n2 == null || arista == null) continue;

            g2.setColor(COLOR_CAMINO);
            g2.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(n1.x, n1.y, n2.x, n2.y);
            g2.setStroke(trazoOriginal);

            // Flecha en el extremo del destino (borde del círculo)
            double dx = n2.x - n1.x, dy = n2.y - n1.y;
            double largo = Math.hypot(dx, dy);
            if (largo > radio * 2) {
                double ux = dx / largo, uy = dy / largo;
                double px = n2.x - ux * radio, py = n2.y - uy * radio;
                int[] xs = {(int) Math.round(px),
                    (int) Math.round(px - ux * 12 - uy * 6), (int) Math.round(px - ux * 12 + uy * 6)};
                int[] ys = {(int) Math.round(py),
                    (int) Math.round(py - uy * 12 + ux * 6), (int) Math.round(py - uy * 12 - ux * 6)};
                g2.fillPolygon(xs, ys, 3);
            }
            g2.setColor(Color.RED);
            g2.drawString(String.valueOf(arista.peso), (n1.x + n2.x) / 2, (n1.y + n2.y) / 2);
        }
        g2.setColor(Color.BLACK);
    }
    
public void eliminarNodoV(String id) {
    nodos.remove(id);
    
    aristas.removeIf(a -> a.origen.equals(id) || a.destino.equals(id));
    repaint();
}


public void eliminarAristaV(String origen, String destino) {
    aristas.removeIf(a -> a.origen.equals(origen) && a.destino.equals(destino));
    
    repaint();
}


public void destruirGrafoV() {
    nodos.clear();
    aristas.clear();
    repaint();
}
}