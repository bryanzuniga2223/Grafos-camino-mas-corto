package backend.optimizacion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;

/**
 * Utilidades de formato para la traza (pensada para una fuente Monospaced).
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public final class Formato {

    public static final String INFINITO = "∞";
    public static final String FLECHA = " → ";

    private Formato() {
    }

    /** 12.0 → "12", 2.5 → "2.5", 0.1 + 0.2 → "0.3", infinito → "∞". */
    public static String num(double d) {
        if (Double.isNaN(d)) return "-";
        if (Double.isInfinite(d)) return d > 0 ? INFINITO : "-" + INFINITO;
        BigDecimal bd = new BigDecimal(d).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros();
        if (bd.compareTo(BigDecimal.ZERO) == 0) return "0";
        return bd.toPlainString();
    }

    /** Milisegundos con 4 decimales. */
    public static String ms(double milis) {
        return String.format(Locale.ROOT, "%.4f ms", milis);
    }

    /** Rellena con espacios a la derecha hasta el ancho indicado. */
    public static String der(String s, int ancho) {
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < ancho) sb.append(' ');
        return sb.toString();
    }

    /** Rellena con espacios a la izquierda (alineado a la derecha). */
    public static String izq(String s, int ancho) {
        StringBuilder sb = new StringBuilder();
        while (sb.length() + s.length() < ancho) sb.append(' ');
        return sb.append(s).toString();
    }

    public static String repetir(char c, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(c);
        return sb.toString();
    }

    /** "A → B → C" */
    public static String ruta(List<String> ids) {
        return String.join(FLECHA, ids);
    }
}
