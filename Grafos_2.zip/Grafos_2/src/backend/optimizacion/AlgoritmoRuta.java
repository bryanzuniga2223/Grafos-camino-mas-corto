package backend.optimizacion;

import backend.Arista;
import backend.Grafo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Base común de los algoritmos de camino más corto sobre el grafo DIRIGIDO del proyecto.
 *
 * Hace todo lo que comparten Dijkstra y Bellman-Ford: validar la consulta, inicializar
 * dist/previo, relajar aristas (ACEPTA / DESCARTA), reconstruir la ruta, medir el tiempo
 * y escribir la traza en español línea por línea a un receptor (Consumer&lt;String&gt;).
 * Cada subclase solo implementa su ciclo principal en {@link #resolver()}.
 *
 * El tiempo se mide con System.nanoTime() y NO incluye las pausas de animación ni la
 * construcción/escritura de la traza (el "reloj" se detiene mientras se escribe).
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public abstract class AlgoritmoRuta {

    private Consumer<String> receptor;
    private long pausaMs;

    // ----- estado de la ejecución actual (se reinicia en cada llamada a ejecutar) -----
    protected List<String> nodos;
    protected List<Arista> aristas;
    protected Map<String, List<Arista>> ady;
    protected Map<String, Double> dist;
    protected Map<String, String> previo;
    protected String origen;
    protected String destino;
    protected int evaluaciones;
    protected int aceptaciones;
    protected int descartes;
    protected int iteraciones;
    protected boolean cicloNegativo;

    private int numeroSeccion;
    private int anchoEtiqueta;
    private long nanosExcluidos;
    private long inicioPausaReloj;
    private int profundidadPausaReloj;

    protected AlgoritmoRuta(Consumer<String> receptor, long pausaMs) {
        this.receptor = receptor;
        setPausaMs(pausaMs);
    }

    /** Nombre para mostrar ("Dijkstra", "Bellman-Ford"). */
    public abstract String getNombre();

    /** Qué cuenta como iteración, p. ej. "nodos extraídos de la cola de prioridad". */
    protected abstract String unidadIteraciones();

    /** Ciclo principal del algoritmo (se llama solo si origen != destino). */
    protected abstract void resolver();

    /** Comprobaciones propias del algoritmo antes de empezar (Dijkstra: pesos no negativos). */
    protected void validarAplicabilidad(List<Arista> aristas) {
    }

    /** Línea extra para el encabezado de la traza (o null). */
    protected String notaAplicabilidad() {
        return null;
    }

    /** Columna "estado" de la tabla final (null = sin columna). */
    protected String estadoNodo(String id) {
        return null;
    }

    /** Nota opcional que se escribe debajo de la tabla final. */
    protected String notaTablaFinal() {
        return null;
    }

    public void setReceptor(Consumer<String> receptor) { this.receptor = receptor; }

    public void setPausaMs(long pausaMs) { this.pausaMs = Math.max(0, pausaMs); }

    // =====================================================================
    //  Validación de la consulta
    // =====================================================================

    /**
     * Valida grafo y extremos. Lanza IllegalArgumentException con un mensaje en español
     * listo para mostrarse al usuario.
     */
    public static void validarConsulta(Grafo grafo, String origen, String destino) {
        if (grafo == null) {
            throw new IllegalArgumentException(
                    "El grafo no ha sido creado. Pulse 'Crear Grafo' (o 'Red de ejemplo') primero.");
        }
        if (grafo.estaVacio()) {
            throw new IllegalArgumentException(
                    "El grafo está vacío: agregue ubicaciones y rutas antes de calcular un camino.");
        }
        validarExtremos(grafo.idsEnOrden(), origen, destino);
    }

    private static void validarExtremos(Collection<String> nodos, String origen, String destino) {
        if (origen == null || origen.trim().isEmpty()) {
            throw new IllegalArgumentException("Debe escribir el ID del nodo ORIGEN.");
        }
        if (destino == null || destino.trim().isEmpty()) {
            throw new IllegalArgumentException("Debe escribir el ID del nodo DESTINO.");
        }
        if (!nodos.contains(origen.trim())) {
            throw new IllegalArgumentException("El nodo origen '" + origen.trim()
                    + "' no existe en el grafo. IDs disponibles: " + listaIds(nodos));
        }
        if (!nodos.contains(destino.trim())) {
            throw new IllegalArgumentException("El nodo destino '" + destino.trim()
                    + "' no existe en el grafo. IDs disponibles: " + listaIds(nodos));
        }
    }

    private static String listaIds(Collection<String> nodos) {
        List<String> l = new ArrayList<>(nodos);
        if (l.size() > 20) {
            return String.join(", ", l.subList(0, 20)) + ", ...";
        }
        return String.join(", ", l);
    }

    // =====================================================================
    //  Ejecución
    // =====================================================================

    /** Valida y ejecuta sobre el grafo del proyecto (usa una copia de sus aristas). */
    public ResultadoRuta ejecutar(Grafo grafo, String origen, String destino) {
        validarConsulta(grafo, origen, destino);
        return ejecutar(grafo.idsEnOrden(), grafo.getAristas(), origen, destino);
    }

    /**
     * Ejecuta sobre una "foto" del grafo: lista de IDs y lista de aristas dirigidas.
     * Así el cálculo en segundo plano no se ve afectado si la ventana modifica el grafo.
     */
    public ResultadoRuta ejecutar(List<String> listaNodos, List<Arista> listaAristas, String origen, String destino) {
        if (listaNodos == null || listaNodos.isEmpty()) {
            throw new IllegalArgumentException(
                    "El grafo está vacío: agregue ubicaciones y rutas antes de calcular un camino.");
        }
        validarExtremos(listaNodos, origen, destino);
        List<Arista> listaA = listaAristas == null ? new ArrayList<>() : new ArrayList<>(listaAristas);
        validarAplicabilidad(listaA);

        reiniciar(listaNodos, listaA, origen.trim(), destino.trim());
        long inicio = System.nanoTime();

        encabezado();

        // 1. INICIALIZACIÓN
        for (String id : nodos) {
            dist.put(id, Double.POSITIVE_INFINITY);
            previo.put(id, null);
        }
        dist.put(this.origen, 0.0);
        abrirSeccion("INICIALIZACIÓN");
        linea("   dist[v] = ∞ y previo[v] = - para todo v; dist[%s] = 0 (origen).", this.origen);
        tablaDistancias(false);

        // 2. ITERACIONES
        abrirSeccion("ITERACIONES");
        if (this.origen.equals(this.destino)) {
            linea("   Origen = destino (%s): su distancia ya es 0 desde la inicialización;", this.origen);
            linea("   no es necesario evaluar ninguna arista.");
        } else {
            resolver();
        }

        // Tabla final y reconstrucción de la ruta
        abrirSeccion("TABLA FINAL DE DISTANCIAS");
        tablaDistancias(true);
        String nota = notaTablaFinal();
        if (nota != null) linea("   %s", nota);

        List<String> ruta = reconstruirRuta();
        List<Double> tramos = costosTramo(ruta);
        boolean alcanzable = !cicloNegativo && !ruta.isEmpty();
        double costo = alcanzable ? dist.get(this.destino) : Double.POSITIVE_INFINITY;
        double tiempoMs = (System.nanoTime() - inicio - nanosExcluidos) / 1_000_000.0;

        ResultadoRuta r = new ResultadoRuta(getNombre(), this.origen, this.destino, ruta, tramos, costo,
                alcanzable, cicloNegativo, evaluaciones, aceptaciones, descartes, iteraciones,
                unidadIteraciones(), tiempoMs);

        seccionResultado(r);
        seccionEstadisticas(r);
        return r;
    }

    private void reiniciar(List<String> listaNodos, List<Arista> listaA, String o, String d) {
        nodos = new ArrayList<>(listaNodos);
        aristas = listaA;
        origen = o;
        destino = d;
        ady = new LinkedHashMap<>();
        dist = new LinkedHashMap<>();
        previo = new LinkedHashMap<>();
        for (String id : nodos) ady.put(id, new ArrayList<>());
        anchoEtiqueta = 0;
        for (Arista a : aristas) {
            List<Arista> salientes = ady.get(a.getOrigen());
            if (salientes == null || !ady.containsKey(a.getDestino())) {
                throw new IllegalArgumentException("La arista " + a + " usa un nodo que no existe.");
            }
            salientes.add(a);
            anchoEtiqueta = Math.max(anchoEtiqueta, etiqueta(a).length());
        }
        evaluaciones = aceptaciones = descartes = iteraciones = 0;
        cicloNegativo = false;
        numeroSeccion = 0;
        nanosExcluidos = 0;
        profundidadPausaReloj = 0;
        alIniciar();
    }

    /** Gancho para que cada algoritmo reinicie su propio estado antes de cada ejecución. */
    protected void alIniciar() {
    }

    // =====================================================================
    //  Relajación (lo común de ambos algoritmos)
    // =====================================================================

    /**
     * Evalúa la arista u→v: si dist[u] + peso &lt; dist[v] la ACEPTA (actualiza dist y previo);
     * si no, la DESCARTA y se conserva el camino actual.
     *
     * @param destinoCerrado true si v ya tiene distancia definitiva (Dijkstra: v ya visitado);
     *                       la arista se descarta sin actualizar
     * @return true si fue aceptada
     */
    protected final boolean relajar(Arista a, boolean destinoCerrado) {
        evaluaciones++;
        String u = a.getOrigen();
        String v = a.getDestino();
        double w = a.getPeso();
        double du = dist.get(u);
        double dv = dist.get(v);
        double nuevo = du + w;
        boolean acepta = !destinoCerrado && nuevo < dv;
        String previoAnterior = previo.get(v);
        if (acepta) {
            aceptaciones++;
            dist.put(v, nuevo);
            previo.put(v, u);
        } else {
            descartes++;
        }

        if (receptor != null) {
            detenerReloj();
            String eti = Formato.der(etiqueta(a) + ":", anchoEtiqueta + 1);
            String calculo = "dist[" + u + "] + peso = " + Formato.num(du) + " + " + Formato.num(w)
                    + " = " + Formato.num(nuevo);
            if (acepta) {
                String tipo = Double.isInfinite(dv)
                        ? "primer camino hacia " + v
                        : "mejora: antes " + Formato.num(dv) + " vía " + previoAnterior;
                emitir("      ACEPTA   " + eti + " " + calculo + " < dist[" + v + "] = " + Formato.num(dv)
                        + " → dist[" + v + "] = " + Formato.num(nuevo) + ", previo[" + v + "] = " + u
                        + "  (" + tipo + ")");
            } else {
                String nota = destinoCerrado ? v + " ya visitado"
                        : (Double.isInfinite(du) ? u + " aún no tiene camino" : null);
                emitir("      DESCARTA " + eti + " " + calculo + " >= dist[" + v + "] = " + Formato.num(dv)
                        + " → se conserva el camino actual" + (nota == null ? "" : "  (" + nota + ")"));
            }
            pausar();
            reanudarReloj();
        }
        return acepta;
    }

    private static String etiqueta(Arista a) {
        return a.getOrigen() + "→" + a.getDestino();
    }

    // =====================================================================
    //  Reconstrucción de la ruta
    // =====================================================================

    private List<String> reconstruirRuta() {
        List<String> ruta = new ArrayList<>();
        if (cicloNegativo || Double.isInfinite(dist.get(destino))) return ruta;
        String actual = destino;
        int guardia = 0;
        while (actual != null && guardia++ <= nodos.size()) {
            ruta.add(0, actual);
            if (actual.equals(origen)) return ruta;
            actual = previo.get(actual);
        }
        return new ArrayList<>(); // no llegó al origen (no debería ocurrir)
    }

    private List<Double> costosTramo(List<String> ruta) {
        List<Double> tramos = new ArrayList<>();
        for (int i = 0; i + 1 < ruta.size(); i++) {
            tramos.add(pesoMinimo(ruta.get(i), ruta.get(i + 1)));
        }
        return tramos;
    }

    /** Peso de la arista u→v (la menor, si hubiera varias); NaN si no existe. */
    protected final double pesoMinimo(String u, String v) {
        double mejor = Double.NaN;
        for (Arista a : ady.get(u)) {
            if (a.getDestino().equals(v) && (Double.isNaN(mejor) || a.getPeso() < mejor)) {
                mejor = a.getPeso();
            }
        }
        return mejor;
    }

    // =====================================================================
    //  Secciones de la traza
    // =====================================================================

    private void encabezado() {
        if (receptor == null) return;
        detenerReloj();
        String barra = Formato.repetir('═', 78);
        linea(barra);
        linea(" %s  |  Origen: %s  →  Destino: %s", getNombre().toUpperCase(Locale.ROOT), origen, destino);
        linea(" Grafo dirigido: %d nodos, %d aristas", nodos.size(), aristas.size());
        String nota = notaAplicabilidad();
        if (nota != null) linea(" %s", nota);
        linea(barra);
        reanudarReloj();
    }

    protected final void abrirSeccion(String titulo) {
        numeroSeccion++;
        if (receptor == null) return;
        detenerReloj();
        String t = numeroSeccion + ". " + titulo;
        emitir("");
        emitir(t);
        emitir(Formato.repetir('─', t.length()));
        reanudarReloj();
    }

    private void tablaDistancias(boolean conEstado) {
        if (receptor == null) return;
        detenerReloj();
        int a1 = "Nodo".length();
        int a2 = "dist".length();
        int a3 = "previo".length();
        boolean hayEstado = conEstado && estadoNodo(origen) != null;
        int a4 = "estado".length();
        for (String id : nodos) {
            a1 = Math.max(a1, id.length());
            a2 = Math.max(a2, Formato.num(dist.get(id)).length());
            a3 = Math.max(a3, previo.get(id) == null ? 1 : previo.get(id).length());
            if (hayEstado) a4 = Math.max(a4, estadoNodo(id).length());
        }
        String cab = "   " + Formato.der("Nodo", a1) + " | " + Formato.izq("dist", a2) + " | " + Formato.der("previo", a3);
        String sep = "   " + Formato.repetir('-', a1) + "-+-" + Formato.repetir('-', a2) + "-+-" + Formato.repetir('-', a3);
        if (hayEstado) {
            cab += " | estado";
            sep += "-+-" + Formato.repetir('-', a4);
        }
        emitir(cab);
        emitir(sep);
        for (String id : nodos) {
            String p = previo.get(id) == null ? "-" : previo.get(id);
            String fila = "   " + Formato.der(id, a1) + " | " + Formato.izq(Formato.num(dist.get(id)), a2)
                    + " | " + (hayEstado ? Formato.der(p, a3) + " | " + estadoNodo(id) : p);
            emitir(fila);
        }
        reanudarReloj();
    }

    private void seccionResultado(ResultadoRuta r) {
        abrirSeccion("RESULTADO");
        if (receptor == null) return;
        detenerReloj();
        if (r.isCicloNegativo()) {
            emitir("   SIN RUTA ÓPTIMA: existe un ciclo de peso negativo alcanzable desde " + origen + ";");
            emitir("   recorriéndolo una y otra vez el costo bajaría sin límite.");
        } else if (!r.isAlcanzable()) {
            emitir("   DESTINO INACCESIBLE: no existe camino de " + origen + " a " + destino);
            List<String> alcanzados = new ArrayList<>();
            for (String id : nodos) {
                if (!Double.isInfinite(dist.get(id))) alcanzados.add(id);
            }
            emitir("   Desde " + origen + " solo se puede llegar a: " + String.join(", ", alcanzados)
                    + " (" + alcanzados.size() + " de " + nodos.size() + " nodos).");
            if (ady.get(origen).isEmpty()) {
                emitir("   Motivo: " + origen + " no tiene rutas de salida.");
            } else if (gradoEntrada(destino) == 0) {
                emitir("   Motivo: " + destino + " no tiene rutas de entrada.");
            } else {
                emitir("   Motivo: ninguna secuencia de rutas (respetando su sentido) conecta ambos nodos.");
            }
        } else if (origen.equals(destino)) {
            emitir("   Origen y destino son el mismo nodo (" + origen + ") → COSTO TOTAL: 0");
            emitir("   No se recorre ninguna ruta.");
        } else {
            List<String> ruta = r.getRuta();
            emitir("   Ruta óptima: " + r.getRutaTexto());
            int anchoTramo = "Tramo".length();
            for (int i = 0; i + 1 < ruta.size(); i++) {
                anchoTramo = Math.max(anchoTramo, (ruta.get(i) + Formato.FLECHA + ruta.get(i + 1)).length());
            }
            int anchoNum = Math.max("Acumulado".length(), Formato.num(r.getCostoTotal()).length());
            emitir("   " + Formato.der("#", 3) + Formato.der("Tramo", anchoTramo) + "  "
                    + Formato.izq("Costo", anchoNum) + "  " + Formato.izq("Acumulado", anchoNum));
            double acumulado = 0;
            for (int i = 0; i + 1 < ruta.size(); i++) {
                double c = r.getCostosTramo().get(i);
                acumulado += c;
                emitir("   " + Formato.der(String.valueOf(i + 1), 3)
                        + Formato.der(ruta.get(i) + Formato.FLECHA + ruta.get(i + 1), anchoTramo) + "  "
                        + Formato.izq(Formato.num(c), anchoNum) + "  " + Formato.izq(Formato.num(acumulado), anchoNum));
            }
            emitir("   COSTO TOTAL: " + Formato.num(r.getCostoTotal()) + "  (" + r.getSaltos()
                    + (r.getSaltos() == 1 ? " tramo)" : " tramos)"));
            double directa = pesoMinimo(origen, destino);
            if (ruta.size() > 2 && !Double.isNaN(directa)) {
                emitir("   Nota: existe la ruta directa " + origen + Formato.FLECHA + destino + " con costo "
                        + Formato.num(directa) + ", pero se DESCARTÓ: el camino por intermedios cuesta "
                        + Formato.num(r.getCostoTotal()) + " (" + Formato.num(directa - r.getCostoTotal()) + " menos).");
            }
        }
        reanudarReloj();
    }

    private int gradoEntrada(String id) {
        int g = 0;
        for (Arista a : aristas) if (a.getDestino().equals(id)) g++;
        return g;
    }

    private void seccionEstadisticas(ResultadoRuta r) {
        abrirSeccion("ESTADÍSTICAS");
        linea("   Evaluaciones de aristas : %d", r.getEvaluaciones());
        linea("   Aceptaciones            : %d", r.getAceptaciones());
        linea("   Descartes               : %d", r.getDescartes());
        linea("   Iteraciones             : %d (%s)", r.getIteraciones(), r.getUnidadIteraciones());
        linea("   Tiempo de cálculo       : %s (System.nanoTime, sin pausas ni escritura de la traza)",
                Formato.ms(r.getTiempoMs()));
        linea(Formato.repetir('═', 78));
    }

    // =====================================================================
    //  Emisión de la traza, pausas y reloj
    // =====================================================================

    /** true si hay alguien escuchando la traza. */
    protected final boolean hayTraza() {
        return receptor != null;
    }

    /**
     * Escribe una línea con formato (el reloj se detiene mientras se construye y escribe).
     * Los argumentos Double se muestran con Formato.num (12.0 → "12", infinito → "∞"),
     * por eso en los formatos se usa %s para las distancias.
     */
    protected final void linea(String formato, Object... args) {
        if (receptor == null) return;
        detenerReloj();
        emitir(formatear(formato, args));
        reanudarReloj();
    }

    /** Igual que linea() pero después hace la pausa de animación. */
    protected final void paso(String formato, Object... args) {
        if (receptor == null) return;
        detenerReloj();
        emitir(formatear(formato, args));
        pausar();
        reanudarReloj();
    }

    private static String formatear(String formato, Object[] args) {
        if (args.length == 0) return formato;
        Object[] a = args.clone();
        for (int i = 0; i < a.length; i++) {
            if (a[i] instanceof Double) a[i] = Formato.num((Double) a[i]);
        }
        return String.format(Locale.ROOT, formato, a);
    }

    private void emitir(String s) {
        receptor.accept(s);
    }

    private void pausar() {
        if (pausaMs <= 0) return;
        try {
            Thread.sleep(pausaMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            pausaMs = 0; // si nos interrumpen, se termina sin más pausas
        }
    }

    protected final void detenerReloj() {
        if (profundidadPausaReloj++ == 0) inicioPausaReloj = System.nanoTime();
    }

    protected final void reanudarReloj() {
        if (--profundidadPausaReloj == 0) nanosExcluidos += System.nanoTime() - inicioPausaReloj;
    }
}
