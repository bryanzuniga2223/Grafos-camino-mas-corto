package backend.optimizacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Resultado de un cálculo de camino más corto (Dijkstra o Bellman-Ford).
 * Es inmutable: se puede pasar sin riesgo del hilo de cálculo al hilo de la interfaz.
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public final class ResultadoRuta {

    private final String algoritmo;
    private final String origen;
    private final String destino;
    private final List<String> ruta;
    private final List<Double> costosTramo;
    private final double costoTotal;
    private final boolean alcanzable;
    private final boolean cicloNegativo;
    private final int evaluaciones;
    private final int aceptaciones;
    private final int descartes;
    private final int iteraciones;
    private final String unidadIteraciones;
    private final double tiempoMs;

    public ResultadoRuta(String algoritmo, String origen, String destino, List<String> ruta,
            List<Double> costosTramo, double costoTotal, boolean alcanzable, boolean cicloNegativo,
            int evaluaciones, int aceptaciones, int descartes, int iteraciones,
            String unidadIteraciones, double tiempoMs) {
        this.algoritmo = algoritmo;
        this.origen = origen;
        this.destino = destino;
        this.ruta = Collections.unmodifiableList(new ArrayList<>(ruta));
        this.costosTramo = Collections.unmodifiableList(new ArrayList<>(costosTramo));
        this.costoTotal = costoTotal;
        this.alcanzable = alcanzable;
        this.cicloNegativo = cicloNegativo;
        this.evaluaciones = evaluaciones;
        this.aceptaciones = aceptaciones;
        this.descartes = descartes;
        this.iteraciones = iteraciones;
        this.unidadIteraciones = unidadIteraciones;
        this.tiempoMs = tiempoMs;
    }

    public String getAlgoritmo() { return algoritmo; }
    public String getOrigen() { return origen; }
    public String getDestino() { return destino; }
    /** IDs de los nodos de la ruta, de origen a destino (vacía si no es alcanzable). */
    public List<String> getRuta() { return ruta; }
    /** Costo de cada tramo de la ruta (tamaño = ruta.size() - 1). */
    public List<Double> getCostosTramo() { return costosTramo; }
    /** Costo total (Double.POSITIVE_INFINITY si no es alcanzable). */
    public double getCostoTotal() { return costoTotal; }
    public boolean isAlcanzable() { return alcanzable; }
    public boolean isCicloNegativo() { return cicloNegativo; }
    public int getEvaluaciones() { return evaluaciones; }
    public int getAceptaciones() { return aceptaciones; }
    public int getDescartes() { return descartes; }
    /** Dijkstra: nodos extraídos de la cola. Bellman-Ford: pasadas realizadas. */
    public int getIteraciones() { return iteraciones; }
    public String getUnidadIteraciones() { return unidadIteraciones; }
    /** Tiempo de cálculo medido con System.nanoTime, sin pausas ni escritura de la traza. */
    public double getTiempoMs() { return tiempoMs; }

    /** Número de tramos (aristas) de la ruta. */
    public int getSaltos() { return Math.max(0, ruta.size() - 1); }

    public String getRutaTexto() {
        if (cicloNegativo) return "SIN RUTA ÓPTIMA (ciclo negativo)";
        return alcanzable ? Formato.ruta(ruta) : "INACCESIBLE";
    }

    public String getCostoTexto() {
        return alcanzable ? Formato.num(costoTotal) : "-";
    }

    /** Texto breve para el área de resultado. */
    public String resumen() {
        StringBuilder sb = new StringBuilder(algoritmo).append(": ");
        if (cicloNegativo) {
            sb.append("ciclo de peso negativo alcanzable desde ").append(origen)
              .append(" → no existe una ruta óptima.");
        } else if (!alcanzable) {
            sb.append("DESTINO INACCESIBLE: no existe camino de ").append(origen).append(" a ").append(destino);
        } else if (origen.equals(destino)) {
            sb.append(origen).append(" (origen = destino)\nCosto total: 0 (no se recorre ninguna ruta)");
        } else {
            sb.append(getRutaTexto()).append("\nCosto total: ").append(Formato.num(costoTotal))
              .append("  (").append(getSaltos()).append(getSaltos() == 1 ? " tramo: " : " tramos: ");
            for (int i = 0; i < costosTramo.size(); i++) {
                if (i > 0) sb.append(" + ");
                sb.append(Formato.num(costosTramo.get(i)));
            }
            sb.append(")");
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return getRutaTexto() + " | costo " + getCostoTexto();
    }
}
