package backend.optimizacion;

import backend.Arista;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Algoritmo de Dijkstra con cola de prioridad (montículo binario, java.util.PriorityQueue).
 *
 * Idea: en cada iteración se extrae el nodo NO visitado con menor distancia; como no hay
 * pesos negativos, esa distancia ya es definitiva y se relajan sus aristas salientes.
 * Las aristas hacia nodos ya visitados se reportan como DESCARTA.
 * Se detiene en cuanto extrae el destino (su distancia ya no puede mejorar).
 *
 * Complejidad: O((V + E) log V) tiempo, O(V + E) memoria.
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public class Dijkstra extends AlgoritmoRuta {

    /** Entrada de la cola: (nodo, distancia) con desempate por orden de llegada. */
    private static final class Entrada implements Comparable<Entrada> {
        final String id;
        final double dist;
        final long orden;

        Entrada(String id, double dist, long orden) {
            this.id = id;
            this.dist = dist;
            this.orden = orden;
        }

        @Override
        public int compareTo(Entrada o) {
            int c = Double.compare(dist, o.dist);
            return c != 0 ? c : Long.compare(orden, o.orden);
        }
    }

    private Set<String> visitados = new HashSet<>();
    private boolean detenidoEnDestino;

    public Dijkstra() {
        this(null, 0);
    }

    public Dijkstra(Consumer<String> receptor, long pausaMs) {
        super(receptor, pausaMs);
    }

    @Override
    public String getNombre() {
        return "Dijkstra";
    }

    @Override
    protected String unidadIteraciones() {
        return "nodos extraídos de la cola de prioridad";
    }

    /**
     * Dijkstra solo es correcto si ningún peso es negativo. Lanza IllegalArgumentException
     * indicando la primera arista negativa encontrada.
     */
    public static void validarPesosNoNegativos(Collection<Arista> aristas) {
        if (aristas == null) return;
        for (Arista a : aristas) {
            if (a.getPeso() < 0) {
                throw new IllegalArgumentException("Dijkstra no admite pesos negativos: la ruta "
                        + a.getOrigen() + " → " + a.getDestino() + " tiene peso " + Formato.num(a.getPeso())
                        + ". Use Bellman-Ford para este grafo.");
            }
        }
    }

    @Override
    protected void validarAplicabilidad(List<Arista> aristas) {
        validarPesosNoNegativos(aristas);
    }

    @Override
    protected String notaAplicabilidad() {
        return "Validación previa: ningún peso es negativo → Dijkstra es aplicable.";
    }

    @Override
    protected void alIniciar() {
        visitados = new HashSet<>();
        detenidoEnDestino = false;
    }

    @Override
    protected void resolver() {
        PriorityQueue<Entrada> cola = new PriorityQueue<>();
        long orden = 0;
        cola.add(new Entrada(origen, 0.0, orden++));
        linea("   Cola de prioridad inicial: [%s:0]", origen);

        while (!cola.isEmpty()) {
            Entrada e = cola.poll();
            if (visitados.contains(e.id)) {
                // Entrada obsoleta: el nodo ya salió antes con una distancia menor.
                linea("   · Se ignora (%s, %s) en la cola: %s ya tiene distancia definitiva %s",
                        e.id, e.dist, e.id, dist.get(e.id));
                continue;
            }
            visitados.add(e.id);
            iteraciones++;
            linea("");
            paso("   Iteración %d: se extrae %s con dist = %s (distancia definitiva)",
                    iteraciones, e.id, e.dist);

            if (e.id.equals(destino)) {
                linea("      %s es el DESTINO: su distancia ya no puede mejorar → se detiene la búsqueda.", e.id);
                detenidoEnDestino = true;
                break;
            }

            List<Arista> salientes = ady.get(e.id);
            if (salientes.isEmpty()) {
                linea("      %s no tiene rutas de salida.", e.id);
            }
            for (Arista a : salientes) {
                String v = a.getDestino();
                if (relajar(a, visitados.contains(v))) {
                    cola.add(new Entrada(v, dist.get(v), orden++));
                }
            }
            if (hayTraza()) {
                detenerReloj();
                linea("      Cola de prioridad: %s", describirCola(cola));
                reanudarReloj();
            }
        }

        if (!detenidoEnDestino) {
            linea("");
            linea("   La cola quedó vacía: ya no hay más nodos alcanzables desde %s.", origen);
        }
    }

    /** Contenido vigente de la cola, ordenado (sin entradas obsoletas). */
    private String describirCola(PriorityQueue<Entrada> cola) {
        List<Entrada> lista = new ArrayList<>();
        for (Entrada x : cola) {
            if (!visitados.contains(x.id) && x.dist == dist.get(x.id)) lista.add(x);
        }
        lista.sort(null);
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < lista.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(lista.get(i).id).append(':').append(Formato.num(lista.get(i).dist));
        }
        return sb.append(']').toString();
    }

    @Override
    protected String estadoNodo(String id) {
        if (visitados.contains(id) || (id.equals(origen) && origen.equals(destino))) return "definitiva";
        return Double.isInfinite(dist.get(id)) ? "sin alcanzar" : "tentativa";
    }

    @Override
    protected String notaTablaFinal() {
        if (origen.equals(destino)) return null;
        return detenidoEnDestino
                ? "(Se detuvo al extraer el destino; los nodos \"tentativa\" no se terminaron de procesar.)"
                : null;
    }
}
