package backend.optimizacion;

import backend.Arista;
import java.util.function.Consumer;

/**
 * Algoritmo de Bellman-Ford.
 *
 * Idea: hace hasta V-1 pasadas; en cada pasada relaja TODAS las aristas del grafo en el
 * mismo orden. Un camino más corto sin ciclos tiene como máximo V-1 aristas, así que tras
 * V-1 pasadas las distancias son óptimas. Si una pasada no cambia nada se termina antes
 * (terminación temprana). Al final se hace una pasada extra de VERIFICACIÓN: si alguna
 * arista todavía mejora una distancia, existe un ciclo de peso negativo.
 *
 * Complejidad: O(V · E) tiempo, O(V) memoria adicional. Admite pesos negativos.
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public class BellmanFord extends AlgoritmoRuta {

    public BellmanFord() {
        this(null, 0);
    }

    public BellmanFord(Consumer<String> receptor, long pausaMs) {
        super(receptor, pausaMs);
    }

    @Override
    public String getNombre() {
        return "Bellman-Ford";
    }

    @Override
    protected String unidadIteraciones() {
        return "pasadas completas sobre todas las aristas";
    }

    @Override
    protected void resolver() {
        int maxPasadas = nodos.size() - 1;
        linea("   Se harán como máximo V-1 = %d pasadas; en cada una se evalúan las %d aristas en el mismo orden.",
                maxPasadas, aristas.size());

        for (int p = 1; p <= maxPasadas; p++) {
            iteraciones++;
            linea("");
            paso("   Pasada %d de %d", p, maxPasadas);
            int cambios = 0;
            for (Arista a : aristas) {
                if (relajar(a, false)) cambios++;
            }
            if (cambios == 0) {
                linea("   ⇒ Pasada %d sin cambios: TERMINACIÓN TEMPRANA.", p);
                if (p < maxPasadas) {
                    linea("     Ninguna distancia mejoró, así que las pasadas %d a %d tampoco cambiarían nada.",
                            p + 1, maxPasadas);
                }
                break;
            }
            linea("   ⇒ Pasada %d: %d cambio(s).", p, cambios);
        }

        verificarCiclosNegativos();
    }

    /** Pasada extra: si todavía se puede mejorar alguna distancia, hay un ciclo negativo. */
    private void verificarCiclosNegativos() {
        abrirSeccion("VERIFICACIÓN DE CICLOS NEGATIVOS");
        linea("   Se revisan otra vez las %d aristas: si alguna todavía mejorara una distancia,", aristas.size());
        linea("   existiría un ciclo de peso negativo alcanzable desde %s.", origen);
        for (Arista a : aristas) {
            double du = dist.get(a.getOrigen());
            if (!Double.isInfinite(du) && du + a.getPeso() < dist.get(a.getDestino())) {
                cicloNegativo = true;
                linea("   CICLO NEGATIVO DETECTADO: %s → %s aún mejora dist[%s] (%s + %s = %s < %s).",
                        a.getOrigen(), a.getDestino(), a.getDestino(), du,
                        a.getPeso(), du + a.getPeso(), dist.get(a.getDestino()));
                linea("   Las distancias no están bien definidas: no existe una ruta óptima.");
                return;
            }
        }
        linea("   Ninguna arista mejora una distancia → NO hay ciclos negativos; las distancias son óptimas.");
        linea("   (Aristas revisadas en la verificación: %d; no se suman a las evaluaciones.)", aristas.size());
    }
}
