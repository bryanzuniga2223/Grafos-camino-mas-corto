package backend.optimizacion;

import java.util.ArrayList;
import java.util.List;

/**
 * Tabla comparativa entre dos resultados (por ejemplo Dijkstra vs Bellman-Ford).
 *
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public final class ComparacionAlgoritmos {

    private ComparacionAlgoritmos() {
    }

    /** true si ambos llegaron al mismo costo óptimo (o ambos concluyen que es inaccesible). */
    public static boolean mismoCosto(ResultadoRuta a, ResultadoRuta b) {
        if (a.isCicloNegativo() || b.isCicloNegativo()) {
            return a.isCicloNegativo() == b.isCicloNegativo();
        }
        if (a.isAlcanzable() != b.isAlcanzable()) return false;
        if (!a.isAlcanzable()) return true;
        double x = a.getCostoTotal();
        double y = b.getCostoTotal();
        return Math.abs(x - y) <= 1e-9 * Math.max(1.0, Math.max(Math.abs(x), Math.abs(y)));
    }

    /** Líneas de la tabla comparativa (alineadas para fuente Monospaced). */
    public static List<String> tabla(ResultadoRuta a, ResultadoRuta b) {
        String[][] filas = {
            {"Ruta", a.getRutaTexto(), b.getRutaTexto()},
            {"Costo total", a.getCostoTexto(), b.getCostoTexto()},
            {"Tramos", a.isAlcanzable() ? String.valueOf(a.getSaltos()) : "-",
                b.isAlcanzable() ? String.valueOf(b.getSaltos()) : "-"},
            {"Evaluaciones", String.valueOf(a.getEvaluaciones()), String.valueOf(b.getEvaluaciones())},
            {"Aceptaciones", String.valueOf(a.getAceptaciones()), String.valueOf(b.getAceptaciones())},
            {"Descartes", String.valueOf(a.getDescartes()), String.valueOf(b.getDescartes())},
            {"Iteraciones", a.getIteraciones() + " " + corto(a), b.getIteraciones() + " " + corto(b)},
            {"Tiempo", Formato.ms(a.getTiempoMs()), Formato.ms(b.getTiempoMs())},
        };
        int c0 = "Métrica".length();
        int c1 = a.getAlgoritmo().length();
        int c2 = b.getAlgoritmo().length();
        for (String[] f : filas) {
            c0 = Math.max(c0, f[0].length());
            c1 = Math.max(c1, f[1].length());
            c2 = Math.max(c2, f[2].length());
        }
        List<String> l = new ArrayList<>();
        String barra = Formato.repetir('═', 78);
        l.add(barra);
        l.add(" COMPARACIÓN: " + a.getAlgoritmo().toUpperCase(java.util.Locale.ROOT) + " vs " + b.getAlgoritmo().toUpperCase(java.util.Locale.ROOT)
                + "  |  " + a.getOrigen() + " → " + a.getDestino());
        l.add(barra);
        l.add("   " + Formato.der("Métrica", c0) + " | " + Formato.der(a.getAlgoritmo(), c1) + " | " + b.getAlgoritmo());
        l.add("   " + Formato.repetir('-', c0) + "-+-" + Formato.repetir('-', c1) + "-+-" + Formato.repetir('-', c2));
        for (String[] f : filas) {
            l.add("   " + Formato.der(f[0], c0) + " | " + Formato.der(f[1], c1) + " | " + f[2]);  // sin relleno final
        }
        l.add("");
        l.add("   " + conclusion(a, b));
        if (mismoCosto(a, b) && a.isAlcanzable() && !a.getRuta().equals(b.getRuta())) {
            l.add("   (Las rutas difieren pero cuestan lo mismo: hay un empate entre caminos óptimos.)");
        }
        if (a.isAlcanzable() || b.isAlcanzable()) {
            ResultadoRuta menos = a.getEvaluaciones() <= b.getEvaluaciones() ? a : b;
            ResultadoRuta mas = menos == a ? b : a;
            if (menos.getEvaluaciones() < mas.getEvaluaciones()) {
                l.add("   " + menos.getAlgoritmo() + " evaluó " + (mas.getEvaluaciones() - menos.getEvaluaciones())
                        + " aristas menos que " + mas.getAlgoritmo() + ".");
            }
        }
        l.add("   Nota: en grafos tan pequeños el tiempo (fracciones de ms) varía por el arranque de la JVM;");
        l.add("   la medida de trabajo más estable es el número de evaluaciones de aristas.");
        l.add(barra);
        return l;
    }

    public static String conclusion(ResultadoRuta a, ResultadoRuta b) {
        if (!mismoCosto(a, b)) {
            return "RESULTADO: los algoritmos NO coinciden (" + a.getCostoTexto() + " vs " + b.getCostoTexto() + ").";
        }
        if (a.isCicloNegativo()) {
            return "RESULTADO: ambos detectan un ciclo negativo; no existe costo óptimo.";
        }
        if (!a.isAlcanzable()) {
            return "RESULTADO: ambos coinciden en que el destino es INACCESIBLE.";
        }
        return "RESULTADO: ambos algoritmos llegaron al MISMO costo óptimo (" + a.getCostoTexto() + ").";
    }

    private static String corto(ResultadoRuta r) {
        return r.getAlgoritmo().startsWith("Dijkstra") ? "nodos extraídos" : "pasadas";
    }
}
