# Actividad 3.4 — Caminos más cortos (Dijkstra y Bellman-Ford)

Proyecto: `Grafos_2` (copia de `Grafos_1`, Actividad 3.3).
Autores: Gonzalez Nuñez Isai · Zuñiga de Leon Bryan

---

## 4. Trazas reales sobre la red de ejemplo

### Red de ejemplo (`ControladorRutas.crearRedEjemplo()`)

Grafo **dirigido** con 8 ubicaciones de Jalisco y 14 aristas (pesos en km aproximados, con fines didácticos).
Una carretera de doble sentido se guarda como **dos** aristas.

| ID  | Ubicación              | Rutas de salida (destino, km)       |
|-----|------------------------|-------------------------------------|
| GDL | Guadalajara            | ZAP (12), TLQ (10), **CHA (65, un solo sentido)** |
| ZAP | Zapopan                | GDL (12), TLJ (28), **TEQ (55, un solo sentido)** |
| TLQ | San Pedro Tlaquepaque  | GDL (10), TON (8), TLJ (18)         |
| TON | Tonalá                 | TLQ (8)                             |
| TLJ | Tlajomulco de Zúñiga   | TLQ (18), ZAP (28), CHA (30)        |
| CHA | Chapala                | TLJ (30)                            |
| TEQ | Tequila                | (sin rutas de salida)               |
| PVR | Puerto Vallarta        | (sin conexión: nodo aislado)        |

Casos que cubre:

| Caso | Consulta | Resultado esperado |
|------|----------|--------------------|
| Vecinos directos | GDL → ZAP | 12 |
| Directa más cara que por intermedios | GDL → CHA | directa 65 **descartada**; GDL → TLQ → TLJ → CHA = 58 |
| 3 o más saltos | TON → CHA / TON → TEQ | 56 (3 saltos) / 85 (4 saltos) |
| Un solo sentido recorrido al revés | TEQ → ZAP | DESTINO INACCESIBLE |
| Nodo sin conexión | GDL → PVR | DESTINO INACCESIBLE |

### 4.1 Dijkstra, GDL → CHA (traza completa)

```text
══════════════════════════════════════════════════════════════════════════════
 DIJKSTRA  |  Origen: GDL  →  Destino: CHA
 Grafo dirigido: 8 nodos, 14 aristas
 Validación previa: ningún peso es negativo → Dijkstra es aplicable.
══════════════════════════════════════════════════════════════════════════════

1. INICIALIZACIÓN
─────────────────
   dist[v] = ∞ y previo[v] = - para todo v; dist[GDL] = 0 (origen).
   Nodo | dist | previo
   -----+------+-------
   GDL  |    0 | -
   ZAP  |    ∞ | -
   TLQ  |    ∞ | -
   TON  |    ∞ | -
   TLJ  |    ∞ | -
   CHA  |    ∞ | -
   TEQ  |    ∞ | -
   PVR  |    ∞ | -

2. ITERACIONES
──────────────
   Cola de prioridad inicial: [GDL:0]

   Iteración 1: se extrae GDL con dist = 0 (distancia definitiva)
      ACEPTA   GDL→ZAP: dist[GDL] + peso = 0 + 12 = 12 < dist[ZAP] = ∞ → dist[ZAP] = 12, previo[ZAP] = GDL  (primer camino hacia ZAP)
      ACEPTA   GDL→TLQ: dist[GDL] + peso = 0 + 10 = 10 < dist[TLQ] = ∞ → dist[TLQ] = 10, previo[TLQ] = GDL  (primer camino hacia TLQ)
      ACEPTA   GDL→CHA: dist[GDL] + peso = 0 + 65 = 65 < dist[CHA] = ∞ → dist[CHA] = 65, previo[CHA] = GDL  (primer camino hacia CHA)
      Cola de prioridad: [TLQ:10, ZAP:12, CHA:65]

   Iteración 2: se extrae TLQ con dist = 10 (distancia definitiva)
      DESCARTA TLQ→GDL: dist[TLQ] + peso = 10 + 10 = 20 >= dist[GDL] = 0 → se conserva el camino actual  (GDL ya visitado)
      ACEPTA   TLQ→TON: dist[TLQ] + peso = 10 + 8 = 18 < dist[TON] = ∞ → dist[TON] = 18, previo[TON] = TLQ  (primer camino hacia TON)
      ACEPTA   TLQ→TLJ: dist[TLQ] + peso = 10 + 18 = 28 < dist[TLJ] = ∞ → dist[TLJ] = 28, previo[TLJ] = TLQ  (primer camino hacia TLJ)
      Cola de prioridad: [ZAP:12, TON:18, TLJ:28, CHA:65]

   Iteración 3: se extrae ZAP con dist = 12 (distancia definitiva)
      DESCARTA ZAP→GDL: dist[ZAP] + peso = 12 + 12 = 24 >= dist[GDL] = 0 → se conserva el camino actual  (GDL ya visitado)
      DESCARTA ZAP→TLJ: dist[ZAP] + peso = 12 + 28 = 40 >= dist[TLJ] = 28 → se conserva el camino actual
      ACEPTA   ZAP→TEQ: dist[ZAP] + peso = 12 + 55 = 67 < dist[TEQ] = ∞ → dist[TEQ] = 67, previo[TEQ] = ZAP  (primer camino hacia TEQ)
      Cola de prioridad: [TON:18, TLJ:28, CHA:65, TEQ:67]

   Iteración 4: se extrae TON con dist = 18 (distancia definitiva)
      DESCARTA TON→TLQ: dist[TON] + peso = 18 + 8 = 26 >= dist[TLQ] = 10 → se conserva el camino actual  (TLQ ya visitado)
      Cola de prioridad: [TLJ:28, CHA:65, TEQ:67]

   Iteración 5: se extrae TLJ con dist = 28 (distancia definitiva)
      DESCARTA TLJ→TLQ: dist[TLJ] + peso = 28 + 18 = 46 >= dist[TLQ] = 10 → se conserva el camino actual  (TLQ ya visitado)
      DESCARTA TLJ→ZAP: dist[TLJ] + peso = 28 + 28 = 56 >= dist[ZAP] = 12 → se conserva el camino actual  (ZAP ya visitado)
      ACEPTA   TLJ→CHA: dist[TLJ] + peso = 28 + 30 = 58 < dist[CHA] = 65 → dist[CHA] = 58, previo[CHA] = TLJ  (mejora: antes 65 vía GDL)
      Cola de prioridad: [CHA:58, TEQ:67]

   Iteración 6: se extrae CHA con dist = 58 (distancia definitiva)
      CHA es el DESTINO: su distancia ya no puede mejorar → se detiene la búsqueda.

3. TABLA FINAL DE DISTANCIAS
────────────────────────────
   Nodo | dist | previo | estado
   -----+------+--------+-------------
   GDL  |    0 | -      | definitiva
   ZAP  |   12 | GDL    | definitiva
   TLQ  |   10 | GDL    | definitiva
   TON  |   18 | TLQ    | definitiva
   TLJ  |   28 | TLQ    | definitiva
   CHA  |   58 | TLJ    | definitiva
   TEQ  |   67 | ZAP    | tentativa
   PVR  |    ∞ | -      | sin alcanzar
   (Se detuvo al extraer el destino; los nodos "tentativa" no se terminaron de procesar.)

4. RESULTADO
────────────
   Ruta óptima: GDL → TLQ → TLJ → CHA
   #  Tramo          Costo  Acumulado
   1  GDL → TLQ         10         10
   2  TLQ → TLJ         18         28
   3  TLJ → CHA         30         58
   COSTO TOTAL: 58  (3 tramos)
   Nota: existe la ruta directa GDL → CHA con costo 65, pero se DESCARTÓ: el camino por intermedios cuesta 58 (7 menos).

5. ESTADÍSTICAS
───────────────
   Evaluaciones de aristas : 13
   Aceptaciones            : 7
   Descartes               : 6
   Iteraciones             : 6 (nodos extraídos de la cola de prioridad)
   Tiempo de cálculo       : 0.7670 ms (System.nanoTime, sin pausas ni escritura de la traza)
══════════════════════════════════════════════════════════════════════════════
```

### 4.2 Bellman-Ford, GDL → CHA (traza completa)

```text
══════════════════════════════════════════════════════════════════════════════
 BELLMAN-FORD  |  Origen: GDL  →  Destino: CHA
 Grafo dirigido: 8 nodos, 14 aristas
══════════════════════════════════════════════════════════════════════════════

1. INICIALIZACIÓN
─────────────────
   dist[v] = ∞ y previo[v] = - para todo v; dist[GDL] = 0 (origen).
   Nodo | dist | previo
   -----+------+-------
   GDL  |    0 | -
   ZAP  |    ∞ | -
   TLQ  |    ∞ | -
   TON  |    ∞ | -
   TLJ  |    ∞ | -
   CHA  |    ∞ | -
   TEQ  |    ∞ | -
   PVR  |    ∞ | -

2. ITERACIONES
──────────────
   Se harán como máximo V-1 = 7 pasadas; en cada una se evalúan las 14 aristas en el mismo orden.

   Pasada 1 de 7
      ACEPTA   GDL→ZAP: dist[GDL] + peso = 0 + 12 = 12 < dist[ZAP] = ∞ → dist[ZAP] = 12, previo[ZAP] = GDL  (primer camino hacia ZAP)
      ACEPTA   GDL→TLQ: dist[GDL] + peso = 0 + 10 = 10 < dist[TLQ] = ∞ → dist[TLQ] = 10, previo[TLQ] = GDL  (primer camino hacia TLQ)
      ACEPTA   GDL→CHA: dist[GDL] + peso = 0 + 65 = 65 < dist[CHA] = ∞ → dist[CHA] = 65, previo[CHA] = GDL  (primer camino hacia CHA)
      DESCARTA ZAP→GDL: dist[ZAP] + peso = 12 + 12 = 24 >= dist[GDL] = 0 → se conserva el camino actual
      ACEPTA   ZAP→TLJ: dist[ZAP] + peso = 12 + 28 = 40 < dist[TLJ] = ∞ → dist[TLJ] = 40, previo[TLJ] = ZAP  (primer camino hacia TLJ)
      ACEPTA   ZAP→TEQ: dist[ZAP] + peso = 12 + 55 = 67 < dist[TEQ] = ∞ → dist[TEQ] = 67, previo[TEQ] = ZAP  (primer camino hacia TEQ)
      DESCARTA TLQ→GDL: dist[TLQ] + peso = 10 + 10 = 20 >= dist[GDL] = 0 → se conserva el camino actual
      ACEPTA   TLQ→TON: dist[TLQ] + peso = 10 + 8 = 18 < dist[TON] = ∞ → dist[TON] = 18, previo[TON] = TLQ  (primer camino hacia TON)
      ACEPTA   TLQ→TLJ: dist[TLQ] + peso = 10 + 18 = 28 < dist[TLJ] = 40 → dist[TLJ] = 28, previo[TLJ] = TLQ  (mejora: antes 40 vía ZAP)
      DESCARTA TON→TLQ: dist[TON] + peso = 18 + 8 = 26 >= dist[TLQ] = 10 → se conserva el camino actual
      DESCARTA TLJ→TLQ: dist[TLJ] + peso = 28 + 18 = 46 >= dist[TLQ] = 10 → se conserva el camino actual
      DESCARTA TLJ→ZAP: dist[TLJ] + peso = 28 + 28 = 56 >= dist[ZAP] = 12 → se conserva el camino actual
      ACEPTA   TLJ→CHA: dist[TLJ] + peso = 28 + 30 = 58 < dist[CHA] = 65 → dist[CHA] = 58, previo[CHA] = TLJ  (mejora: antes 65 vía GDL)
      DESCARTA CHA→TLJ: dist[CHA] + peso = 58 + 30 = 88 >= dist[TLJ] = 28 → se conserva el camino actual
   ⇒ Pasada 1: 8 cambio(s).

   Pasada 2 de 7
      DESCARTA GDL→ZAP: dist[GDL] + peso = 0 + 12 = 12 >= dist[ZAP] = 12 → se conserva el camino actual
      DESCARTA GDL→TLQ: dist[GDL] + peso = 0 + 10 = 10 >= dist[TLQ] = 10 → se conserva el camino actual
      DESCARTA GDL→CHA: dist[GDL] + peso = 0 + 65 = 65 >= dist[CHA] = 58 → se conserva el camino actual
      DESCARTA ZAP→GDL: dist[ZAP] + peso = 12 + 12 = 24 >= dist[GDL] = 0 → se conserva el camino actual
      DESCARTA ZAP→TLJ: dist[ZAP] + peso = 12 + 28 = 40 >= dist[TLJ] = 28 → se conserva el camino actual
      DESCARTA ZAP→TEQ: dist[ZAP] + peso = 12 + 55 = 67 >= dist[TEQ] = 67 → se conserva el camino actual
      DESCARTA TLQ→GDL: dist[TLQ] + peso = 10 + 10 = 20 >= dist[GDL] = 0 → se conserva el camino actual
      DESCARTA TLQ→TON: dist[TLQ] + peso = 10 + 8 = 18 >= dist[TON] = 18 → se conserva el camino actual
      DESCARTA TLQ→TLJ: dist[TLQ] + peso = 10 + 18 = 28 >= dist[TLJ] = 28 → se conserva el camino actual
      DESCARTA TON→TLQ: dist[TON] + peso = 18 + 8 = 26 >= dist[TLQ] = 10 → se conserva el camino actual
      DESCARTA TLJ→TLQ: dist[TLJ] + peso = 28 + 18 = 46 >= dist[TLQ] = 10 → se conserva el camino actual
      DESCARTA TLJ→ZAP: dist[TLJ] + peso = 28 + 28 = 56 >= dist[ZAP] = 12 → se conserva el camino actual
      DESCARTA TLJ→CHA: dist[TLJ] + peso = 28 + 30 = 58 >= dist[CHA] = 58 → se conserva el camino actual
      DESCARTA CHA→TLJ: dist[CHA] + peso = 58 + 30 = 88 >= dist[TLJ] = 28 → se conserva el camino actual
   ⇒ Pasada 2 sin cambios: TERMINACIÓN TEMPRANA.
     Ninguna distancia mejoró, así que las pasadas 3 a 7 tampoco cambiarían nada.

3. VERIFICACIÓN DE CICLOS NEGATIVOS
───────────────────────────────────
   Se revisan otra vez las 14 aristas: si alguna todavía mejorara una distancia,
   existiría un ciclo de peso negativo alcanzable desde GDL.
   Ninguna arista mejora una distancia → NO hay ciclos negativos; las distancias son óptimas.
   (Aristas revisadas en la verificación: 14; no se suman a las evaluaciones.)

4. TABLA FINAL DE DISTANCIAS
────────────────────────────
   Nodo | dist | previo
   -----+------+-------
   GDL  |    0 | -
   ZAP  |   12 | GDL
   TLQ  |   10 | GDL
   TON  |   18 | TLQ
   TLJ  |   28 | TLQ
   CHA  |   58 | TLJ
   TEQ  |   67 | ZAP
   PVR  |    ∞ | -

5. RESULTADO
────────────
   Ruta óptima: GDL → TLQ → TLJ → CHA
   #  Tramo          Costo  Acumulado
   1  GDL → TLQ         10         10
   2  TLQ → TLJ         18         28
   3  TLJ → CHA         30         58
   COSTO TOTAL: 58  (3 tramos)
   Nota: existe la ruta directa GDL → CHA con costo 65, pero se DESCARTÓ: el camino por intermedios cuesta 58 (7 menos).

6. ESTADÍSTICAS
───────────────
   Evaluaciones de aristas : 28
   Aceptaciones            : 8
   Descartes               : 20
   Iteraciones             : 2 (pasadas completas sobre todas las aristas)
   Tiempo de cálculo       : 0.1200 ms (System.nanoTime, sin pausas ni escritura de la traza)
══════════════════════════════════════════════════════════════════════════════
```

### 4.3 Tabla comparativa real (botón "Comparar")

```text
══════════════════════════════════════════════════════════════════════════════
 COMPARACIÓN: DIJKSTRA vs BELLMAN-FORD  |  GDL → CHA
══════════════════════════════════════════════════════════════════════════════
   Métrica      | Dijkstra              | Bellman-Ford
   -------------+-----------------------+----------------------
   Ruta         | GDL → TLQ → TLJ → CHA | GDL → TLQ → TLJ → CHA
   Costo total  | 58                    | 58
   Tramos       | 3                     | 3
   Evaluaciones | 13                    | 28
   Aceptaciones | 7                     | 8
   Descartes    | 6                     | 20
   Iteraciones  | 6 nodos extraídos     | 2 pasadas
   Tiempo       | 0.7670 ms             | 0.1200 ms

   RESULTADO: ambos algoritmos llegaron al MISMO costo óptimo (58).
   Dijkstra evaluó 15 aristas menos que Bellman-Ford.
   Nota: en grafos tan pequeños el tiempo (fracciones de ms) varía por el arranque de la JVM;
   la medida de trabajo más estable es el número de evaluaciones de aristas.
══════════════════════════════════════════════════════════════════════════════
```

> Los tiempos son de una ejecución real en una JVM recién iniciada; en grafos tan pequeños varían
> de una corrida a otra. La medida de trabajo estable es **evaluaciones de aristas: 13 (Dijkstra) vs 28 (Bellman-Ford)**.

### 4.4 Fragmento: destino inaccesible (Dijkstra, GDL → PVR)

```text
4. RESULTADO
────────────
   DESTINO INACCESIBLE: no existe camino de GDL a PVR
   Desde GDL solo se puede llegar a: GDL, ZAP, TLQ, TON, TLJ, CHA, TEQ (7 de 8 nodos).
   Motivo: PVR no tiene rutas de entrada.
```

---

## 5. Justificación técnica de los algoritmos

### Problema

La red de transporte es un **grafo dirigido y ponderado** (`Grafo`: `LinkedHashMap` de listas de adyacencia;
el peso de cada arista es la distancia en km y la clase `Grafo` exige peso > 0). La consulta del usuario es
"¿cuál es la ruta más barata de un origen a un destino?", es decir, el problema de **camino más corto desde un
solo origen** (*single-source shortest path*). Dijkstra y Bellman-Ford son los dos algoritmos clásicos para
exactamente ese problema; ambos se basan en la misma operación, la **relajación** de una arista u→v:

```text
si dist[u] + peso(u,v) < dist[v]  →  dist[v] = dist[u] + peso(u,v);  previo[v] = u     (ACEPTA)
si no                             →  se conserva el camino actual                     (DESCARTA)
```

La ruta se reconstruye siguiendo `previo[]` desde el destino hasta el origen.

### Dijkstra (`backend.optimizacion.Dijkstra`)

- **Qué hace:** estrategia *voraz*. Usa una cola de prioridad (`PriorityQueue`, montículo binario) y en cada
  iteración extrae el nodo no visitado con menor distancia. Como ningún peso es negativo, esa distancia ya
  no puede mejorar (es **definitiva**); entonces relaja sus aristas salientes. Las aristas hacia nodos ya
  visitados se reportan como DESCARTA. Nuestra implementación se **detiene al extraer el destino**
  y usa *eliminación perezosa* (las entradas viejas de la cola se ignoran).
- **Complejidad:** O((V + E) log V) en tiempo, O(V + E) en memoria.
- **Requisito:** pesos **no negativos**. Por eso, antes de ejecutarlo, `Dijkstra.validarPesosNoNegativos()`
  revisa todas las aristas (y `Grafo.hayPesosNegativos()` está disponible para consultarlo).

### Bellman-Ford (`backend.optimizacion.BellmanFord`)

- **Qué hace:** programación dinámica sobre el número de aristas. Un camino más corto sin ciclos usa a lo
  más V-1 aristas, así que se hacen hasta **V-1 pasadas** y en cada una se relajan **todas** las aristas.
  Si una pasada no produce cambios hay **terminación temprana**. Después hace una pasada de
  **verificación de ciclos negativos**: si alguna arista todavía mejora una distancia, hay un ciclo negativo
  y no existe ruta óptima.
- **Complejidad:** O(V · E) en tiempo, O(V) de memoria adicional.
- **Ventaja:** admite pesos negativos y detecta ciclos negativos (probado en `PruebasCaminos`, prueba 8,
  con una lista de aristas creada a mano, porque `Grafo` no permite pesos negativos).

### Comparación

| Criterio | Dijkstra | Bellman-Ford |
|----------|----------|--------------|
| Estrategia | Voraz + cola de prioridad | Programación dinámica (V-1 pasadas) |
| Tiempo | O((V + E) log V) | O(V · E) |
| Pesos negativos | No | Sí |
| Detecta ciclos negativos | No | Sí |
| Evaluaciones en GDL → CHA (red de ejemplo) | 13 | 28 |
| Iteraciones en GDL → CHA | 6 nodos extraídos | 2 pasadas (terminación temprana) |

### Por qué elegimos estos dos

1. **Resuelven exactamente nuestra consulta** (de un origen a un destino en un grafo dirigido y ponderado),
   sobre la misma estructura `Grafo` de la Actividad 3.3, sin cambiar su comportamiento.
2. **Se complementan:** Dijkstra es el eficiente para nuestro caso real (distancias positivas); Bellman-Ford
   es el general y robusto (pesos negativos, como descuentos o bonificaciones en un costo, y detección de
   ciclos negativos). Ejecutar ambos muestra la diferencia entre eficiencia y generalidad.
3. **Se verifican entre sí:** si los dos llegan al mismo costo, tenemos evidencia de que el resultado es
   correcto. En las pruebas se comparan en los 64 pares de la red de ejemplo y en 50 grafos aleatorios
   (2 783 consultas), además contra Floyd-Warshall como referencia, con 0 discrepancias.
4. **Descartamos:** BFS (solo sirve sin pesos), Floyd-Warshall (O(V³), calcula todos los pares; lo usamos solo
   como referencia en las pruebas) y A* (necesita una heurística como coordenadas reales, que el grafo no tiene).

### Decisiones de implementación

- **Traza en tiempo real:** cada algoritmo envía la traza línea por línea a un `Consumer<String>`; el
  `ControladorRutas` la publica con `SwingWorker.publish()`, así la ventana no se congela y se ve paso a paso
  (la pausa se controla con el slider).
- **Tiempo justo:** `System.nanoTime()` con el cronómetro detenido durante las pausas y la escritura de la traza.
- **Foto del grafo:** antes de iniciar se copian los IDs y las aristas, por lo que modificar el grafo durante
  un cálculo no causa errores; cada consulta nueva usa el grafo actual (consultas consecutivas y después de editar).
- **Validaciones:** grafo null o vacío, origen o destino vacíos o inexistentes, origen = destino (costo 0 explicado),
  pesos negativos para Dijkstra y destino inaccesible (mensaje dentro de la traza).

---

## 6. Guion de video (máximo 5 minutos)

> Ajusten los tiempos a la rúbrica de la actividad. Antes de grabar: abrir Grafos_2 en NetBeans,
> slider en 60 ms y la ventana maximizada.

| Tiempo | Qué se muestra | Qué se dice |
|--------|----------------|-------------|
| 0:00 – 0:20 | Ventana de la aplicación | "Somos Isai González y Bryan Zúñiga. Esta es la Actividad 3.4: sobre el grafo de la 3.3 agregamos el cálculo de caminos más cortos con Dijkstra y Bellman-Ford." |
| 0:20 – 0:50 | NetBeans: paquetes `backend.optimizacion`, `ControladorRutas`, `pruebas` | "El backend tiene una clase base con la relajación común y una clase por algoritmo; el controlador ejecuta el cálculo en un SwingWorker para mostrar la traza en tiempo real. La interfaz la hicimos con arrastrar y soltar." |
| 0:50 – 1:20 | Botón **Red de ejemplo**; señalar el dibujo | "Cargamos 8 ubicaciones de Jalisco. El grafo es dirigido: las carreteras de doble sentido son dos aristas; GDL→CHA y ZAP→TEQ son de un solo sentido, y Puerto Vallarta está aislado." |
| 1:20 – 2:20 | Origen GDL, destino CHA, **Dijkstra**, Calcular | "Primero inicializa todas las distancias en infinito y el origen en 0. En cada iteración extrae el nodo más cercano. Aquí acepta GDL→CHA con 65, pero al llegar a TLJ encuentra 58: es una MEJORA. La ruta directa de 65 se descarta. Las aristas hacia nodos ya visitados aparecen como DESCARTA." Señalar el camino resaltado en naranja y el costo total 58. |
| 2:20 – 3:05 | Mismo origen y destino, **Bellman-Ford** | "Bellman-Ford evalúa todas las aristas en cada pasada. En la pasada 2 no hubo cambios, así que termina antes. Después verifica que no haya ciclos negativos. Llega al mismo costo: 58." |
| 3:05 – 3:45 | Botón **Comparar** | "La tabla compara ruta, costo, evaluaciones, aceptaciones, descartes, iteraciones y tiempo. Ambos llegan al MISMO costo óptimo; Dijkstra evaluó 13 aristas y Bellman-Ford 28: es más eficiente con pesos positivos, mientras que Bellman-Ford es más general." |
| 3:45 – 4:30 | Validaciones | TEQ→ZAP: "sentido único al revés, destino inaccesible". GDL→PVR: "nodo sin conexión". GDL→GDL: "costo 0". Campo vacío y un ID inexistente: mostrar el aviso. Eliminar el vértice TLQ y recalcular GDL→CHA: "ahora la mejor es la directa, 65; el programa usa el grafo actualizado sin reiniciar". |
| 4:30 – 5:00 | Ejecutar `PruebasCaminos` (Run File) y mostrar el RESUMEN | "Las pruebas comparan esperado contra obtenido: vecinos, rutas largas, inaccesibles, validaciones, 50 grafos aleatorios y pesos negativos. Todas pasan. Gracias." |
